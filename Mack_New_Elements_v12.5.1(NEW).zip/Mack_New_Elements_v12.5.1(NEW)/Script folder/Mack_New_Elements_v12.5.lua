﻿-- Mack_New_Elements v12.5.1: DSWR settling no longer spawns SOIL/MUD.
-- Mack_New_Elements v12.5 (from v12.5): neutrons now pass through water-type liquids; distilled water (DSTW) no longer
--   acts as dirty water / makes mud; ROCK has a rough, speckled texture.
-- Mack_New_Elements v12.5 ============================================================
-- v12.5: added MVSL (moving solid), CLNT (coolant), SIBE (sign box eraser), CLUD (cloud), SNWT (stained water).
-- Mack_New_Elements v12.1   (v12.0 + rising gases, ashy smoke, duplicate guard)
-- For The Powder Toy (Lua scripting API).
--
-- What changed compared with v12.0:
--  * Smoke, steam, hydrogen, methane, ammonia and CO now REALLY rise
--    (negative Gravity + a per-frame upward push, so they never sink or hover).
--  * Smoke carries a little ash: it drifts up, slowly thins out, and sometimes
--    leaves a flake of ASH that falls back down.
--  * Duplicate guard: if an element ID is listed twice, the second one is skipped
--    and a warning is printed. Nothing from v12.0 was removed.
--
-- Older notes (v12.0 vs v11.26):
--  * Elements are really registered (elements.allocate + elements.element).
--  * Temperatures are in KELVIN.
--  * One data-driven reaction engine (chances, temperature limits, catalysts,
--    heat release, pressure, by-products).
--  * Real combustion model: ignition temperature, flame contact, smothering,
--    oxygen-boosted explosions, ash/charcoal/smoke/CO2 products.
--  * Descriptions are generated from the real rules.
--  * Animals eat, wander, make products, leave manure, hatch eggs, die from hazards.
--  * Squeezer is a real mouse tool (select SQZE, hold the mouse on the canvas).
-- ============================================================

local GROUP = "MACKELEMENTS"

local EL   = elements
local PP   = sim.partProperty
local PID  = sim.partID
local XRES = sim.XRES
local YRES = sim.YRES
local random, floor, min, max = math.random, math.floor, math.min, math.max

local TP, TL, TS, TG = EL.TYPE_PART, EL.TYPE_LIQUID, EL.TYPE_SOLID, EL.TYPE_GAS
local PCOND  = EL.PROP_CONDUCTS or 0
local PRADIO = EL.PROP_RADIOACTIVE or 0
local PHOT   = EL.PROP_HOT_GLOW or 0
local PNEUT  = EL.PROP_NEUTPENETRATE or 0   -- v12.6: neutrons pass through

-- Every reaction is rolled only on 1 of GATE frames, with the chance multiplied by GATE.
local GATE = 3

-- All temperatures below are Kelvin (0 C = 273.15 K).

-- ============================================================
-- 1. ELEMENT LIST
-- E(id, colour, kind, text, options)
-- kind: powder / liquid / solid / gas / fire / animal
-- options: w=weight hc=heat conduct hi={K,"ID"} lo={K,"ID"} temp=creation temp
--          cond=conducts electricity hot=glows when hot radio=radioactive
--          menu="SC_..." note="extra text"      ("!LAVA" = the standard Powder Toy LAVA)
-- ============================================================
local ELIST = {}
local ELSEEN = {}
local function E(id, col, kind, text, o)
    if ELSEEN[id] then
        print("Mack_New_Elements: duplicate element '" .. id .. "' skipped.")
        return
    end
    ELSEEN[id] = true
    o = o or {}
    o.id, o.col, o.kind, o.text = id, col, kind, text
    ELIST[#ELIST + 1] = o
end

-- ---------- Powders ----------
E("SULF", 0xE6D64A, "powder", "Sulfur (S): a brittle yellow nonmetal that melts easily and boils near 445°C.", {w=88, hc=20, hi={718, "SULG"}})
E("SALT", 0xFFFFFF, "powder", "Table salt (NaCl): white crystals that dissolve in water and only melt at very high temperature.", {w=95, hc=40, hi={1074, "!LAVA"}})
E("IROX", 0xB84A25, "powder", "Iron(III) oxide (Fe₂O₃): the red-brown oxide found in rust and iron ore. It cannot burn.", {w=100, hc=60, hi={1838, "!LAVA"}})
E("SUCR", 0xF5F0D8, "powder", "Sucrose (table sugar): a sweet white powder that dissolves in water and chars when heated.", {w=80, hc=25})
E("BICA", 0xE8E8E8, "powder", "Sodium bicarbonate (NaHCO₃, baking soda): a mild white base that releases CO₂ when heated or mixed with acid.", {w=75, hc=30})
E("SOIL", 0x79502E, "powder", "Soil: mineral grains and organic matter that hold water and support plant growth.", {w=88, hc=35})
E("FRSL", 0x526B2B, "powder", "Fertilised soil: soil enriched with nutrients, so plants grow faster in it.", {w=88, hc=35})
E("SEED", 0x9B713A, "powder", "Seed: a dormant plant embryo. It needs warmth, moisture and soil to germinate.", {w=70, hc=20})
E("URAN", 0x7A9B45, "powder", "Uranium (U): a dense radioactive metal powder (simplified game element).", {w=95, hc=27, radio=true, menu="SC_NUCLEAR"})
E("PLUT", 0x597A3A, "powder", "Plutonium (Pu): a dense radioactive metal powder that fissions more easily than uranium (simplified).", {w=97, hc=10, radio=true, menu="SC_NUCLEAR"})
E("FERT", 0x6D8D36, "powder", "Fertiliser: nutrient-rich powder (nitrogen, phosphorus, potassium) that enriches soil.", {w=75, hc=25})
E("FOOD", 0xC89A4B, "powder", "Food: edible organic matter that animals eat. It spoils when warm.", {w=70, hc=25})
E("WOOL", 0xF0EBDD, "powder", "Wool: a soft animal fibre. It insulates against heat (very low heat conduction) and is flammable.", {w=40, hc=5})
E("FUNG", 0xD8C7A8, "powder", "Fungus (mould and yeast): a decomposer that grows on damp organic matter and ferments sugar.", {w=60, hc=20})
E("SPOR", 0xB8A17C, "powder", "Fungal spore: a very light grain that grows into fungus on damp organic matter.", {w=30, hc=10})
E("ASH", 0x777777, "powder", "Ash: grey mineral residue left after burning. It contains potash, which fertilises soil.", {w=50, hc=40})
E("CEMT", 0xA4A4A4, "powder", "Cement: a fine grey binding powder that sets hard when mixed with water.", {w=90, hc=40})
E("GRVL", 0x99918A, "powder", "Gravel: loose rock fragments used as concrete aggregate and in water filters.", {w=92, hc=40, hi={1473, "LAVA"}})
E("SAND", 0xD9C18B, "powder", "Sand: loose quartz grains. It filters water and fuses into glass at very high temperature.", {w=90, hc=30, hi={1973, "GLAS"}})
E("CLAY", 0xB87856, "powder", "Clay: fine plastic earth that turns to mud when wet and hardens into ceramic when fired.", {w=85, hc=35, hi={1273, "CERA"}})
E("WHSD", 0xD0C9B8, "powder", "White sand: pure quartz sand that melts into clear glass. It filters water like SAND.", {w=88, hc=30, hi={1973, "GLAS"}})
E("RUST", 0xA64F2D, "powder", "Rust: hydrated iron oxide that flakes off corroded iron or steel.", {w=80, hc=25, hi={1838, "!LAVA"}})
E("RDGS", 0x4A3B26, "powder", "Rotting matter: decaying organic material. It slowly turns back into soil and releases gas.", {w=65, hc=20})
E("CRSK", 0xB9B9B9, "powder", "Crushed stone: angular rock chips used in roads, concrete and water filters.", {w=91, hc=40, hi={1473, "LAVA"}})
E("ALOX", 0xE8E4F0, "powder", "Aluminium oxide (Al₂O₃, alumina): a hard white powder that survives extreme heat. It is the product of aluminium corrosion.", {w=95, hc=30, hi={2345, "!LAVA"}, note="Inert: not attacked by ACID or MERC."})
E("PATI", 0x4FA88A, "powder", "Patina (verdigris and copper oxides): the green-blue crust formed when copper and its alloys corrode.", {w=85, hc=25, hi={1500, "!LAVA"}})
E("EGG",  0xF3E8D0, "powder", "Egg: laid by chickens. Kept warm it hatches into a chicken; heated further it cooks into FOOD.", {w=60, hc=20})

-- ---------- Liquids ----------
E("WATR", 0x204DFF, "liquid", "Water (H₂O): freezes into ICE at 0°C and boils into VAPR at 100°C.", {w=30, hc=29, cond=true, lo={273.15, "ICE"}, hi={373.15, "VAPR"}, note="Denser than the fuels and OIL (they float on it); MERC and ACID sink through it."})
E("ETHL", 0xB8D9FF, "liquid", "Ethanol (C₂H₅OH): a volatile, very flammable alcohol and disinfectant that mixes with water.", {w=24, hc=22, note="Floats on WATR."})
E("MERC", 0xB8BEC7, "liquid", "Mercury (Hg): a very dense, toxic liquid metal that conducts electricity.", {w=91, hc=36, cond=true, note="Toxic to animals and plants. IRON, STEL and TITA are not attacked by it."})
E("ACID", 0xB8B8B8, "liquid", "Sulfuric acid (H₂SO₄): a dense, strongly corrosive acid that also strips water out of organic matter.", {w=38, hc=30, cond=true, note="Does not attack GOLD, TITA, LEAD (insoluble sulfate layer), GLAS, CERA, BRIK or ROCK."})
E("MUD",  0x795438, "liquid", "Mud: water-saturated soil. It dries back into soil when warmed.", {w=55, hc=40})
E("PERO", 0xDDEEFF, "liquid", "Hydrogen peroxide (H₂O₂): an unstable oxidiser that breaks down into water and oxygen gas.", {w=36, hc=30})
E("LAVA", 0xFF5A16, "liquid", "Lava: molten rock. It solidifies into ROCK below about 950°C.", {w=62, hc=20, temp=1673, lo={1223, "ROCK"}, hot=true, note="Metals melt into the standard Powder Toy LAVA (it remembers its metal and re-freezes into it)."})
E("MILK", 0xF5F5F0, "liquid", "Milk: a nutrient-rich liquid from cows. It sours and curdles into FOOD.", {w=32, hc=30, lo={272.6, "ICE"}, hi={373.15, "VAPR"}})
E("DSEL", 0x5A5140, "liquid", "Diesel: a heavy oily fuel that is hard to ignite but burns hot and sooty.", {w=27, hc=25, note="Floats on WATR."})
E("OIL",  0x332A20, "liquid", "Oil: a light viscous oil (vegetable or lubricating). It floats on water and coats metal.", {w=26, hc=25, note="A film of OIL stops IRON and STEL rusting."})
E("COIL", 0x262626, "liquid", "Crude oil: unrefined petroleum. Heating it distils lighter fuels out of it.", {w=28, hc=25, note="Floats on WATR."})
E("SLTW", 0x4C83D8, "liquid", "Salt water: water with dissolved salt. It freezes near -21°C and leaves SALT behind when boiled.", {w=33, hc=28, cond=true, lo={252, "ICE"}})
E("DSWR", 0x3566B8, "liquid", "Dirty water: water carrying dirt and pollutants. Sand, gravel, carbon and wool filter it; it slowly settles clean.", {w=31, hc=28, cond=true, lo={272.5, "ICE"}})
E("KRSE", 0x4B3B2B, "liquid", "Kerosene: a light petroleum fuel for heating and aircraft.", {w=25, hc=25, note="Floats on WATR."})
E("UNOL", 0x9B7A3D, "liquid", "Unrefined oil: thick heavy fuel oil left over from crude oil.", {w=29, hc=25})
E("ICEW", 0xB4E8FF, "liquid", "Ice water: near-freezing water that chills whatever touches it. It freezes at 0°C and warms into WATR.", {w=30, hc=40, cond=true, temp=274.15, lo={273.15, "ICE"}, hi={281, "WATR"}})

-- ---------- Solids ----------
E("CARB", 0x333333, "solid", "Carbon (C): a black charcoal or graphite-like solid that conducts electricity and heat.", {w=100, hc=120, cond=true})
E("ICE",  0xB8E8FF, "solid", "Ice: frozen water. It melts into WATR just above 0°C.", {w=92, hc=60, temp=260, hi={273.65, "WATR"}})
E("PLNT", 0x248A36, "solid", "Plant: living plant matter that grows from water and soil and turns CO2 into oxygen.", {w=100, hc=25})
E("WOOD", 0x87552E, "solid", "Wood: a natural building material. It burns into charcoal and ash and rots when damp.", {w=100, hc=20})
E("LEAF", 0x328A3C, "solid", "Leaf: the part of a plant that carries out photosynthesis (CO2 into oxygen).", {w=100, hc=20})
E("ROCK", 0x777777, "solid", "Rock: ordinary igneous rock such as granite or basalt. It melts into LAVA above about 1200°C.", {w=100, hc=40, hi={1473, "LAVA"}, note="Inert to ACID."})
E("STON", 0x999999, "solid", "Stone (limestone): a cut building stone. Acid dissolves it with fizzing CO2, and heat turns it into lime (CEMT).", {w=100, hc=40, hi={2000, "LAVA"}})
E("GLAS", 0xA8DDE8, "solid", "Glass: a hard, brittle, transparent solid. It shatters if hot glass meets cold water.", {w=100, hc=35, hi={1773, "!LAVA"}, note="Inert to ACID."})
E("CERA", 0xE5D9C4, "solid", "Ceramic: hard fired clay. It is a good heat insulator that survives very high temperature.", {w=100, hc=20, hi={2173, "!LAVA"}, note="Inert to ACID."})
E("COPR", 0xB96D43, "solid", "Copper (Cu): a reddish metal with excellent electrical and heat conduction. It slowly corrodes to green patina.", {w=100, hc=235, cond=true, hot=true, hi={1358, "!LAVA"}})
E("BRAS", 0xC49A45, "solid", "Brass: a copper-zinc alloy used for fittings and instruments. It tarnishes slowly.", {w=100, hc=115, cond=true, hot=true, hi={1203, "!LAVA"}})
E("BRNZ", 0xA97848, "solid", "Bronze: a copper-tin alloy that resists corrosion well.", {w=100, hc=80, cond=true, hot=true, hi={1223, "!LAVA"}})
E("TIN",  0xBFC8CE, "solid", "Tin (Sn): a soft silvery metal with a low melting point (232°C).", {w=100, hc=100, cond=true, hot=true, hi={505, "!LAVA"}})
E("ZINC", 0xAAB7C1, "solid", "Zinc (Zn): a bluish metal that protects IRON and STEL from rusting when they touch it.", {w=100, hc=140, cond=true, hot=true, hi={693, "!LAVA"}})
E("IRON", 0x777E85, "solid", "Iron (Fe): a strong metal that rusts in water and air and turns into steel with carbon.", {w=100, hc=90, cond=true, hot=true, hi={1811, "!LAVA"}})
E("STEL", 0x8B969F, "solid", "Steel: iron alloyed with carbon. Stronger than iron and rusts more slowly.", {w=100, hc=65, cond=true, hot=true, hi={1723, "!LAVA"}})
E("GOLD", 0xE8C547, "solid", "Gold (Au): a dense precious metal that does not corrode.", {w=100, hc=188, cond=true, hot=true, hi={1337, "!LAVA"}, note="Not attacked by ACID, water or air. Only MERC dissolves it (amalgam)."})
E("SILV", 0xD5DCE3, "solid", "Silver (Ag): a shiny precious metal with the highest electrical and heat conduction of any metal.", {w=100, hc=251, cond=true, hot=true, hi={1235, "!LAVA"}})
E("ALUM", 0xC4CCD3, "solid", "Aluminium (Al): a light metal protected by a thin oxide skin. It melts at 660°C.", {w=100, hc=206, cond=true, hot=true, hi={933, "!LAVA"}})
E("TITA", 0x929CA8, "solid", "Titanium (Ti): a strong, light, extremely corrosion-resistant metal.", {w=100, hc=40, cond=true, hot=true, hi={1941, "!LAVA"}, note="Not attacked by ACID, MERC, salt water or rust."})
E("LEAD", 0x69717B, "solid", "Lead (Pb): a soft, dense, toxic metal with a low melting point (327°C).", {w=100, hc=50, cond=true, hot=true, hi={600, "!LAVA"}, note="Radiation shield: absorbs neutrons that touch it. Not attacked by ACID (insoluble lead sulfate coating)."})
E("VINE", 0x397A36, "solid", "Vine: a climbing plant stem that creeps over walls, wood and stone when watered.", {w=100, hc=20})
E("MOSS", 0x547A3B, "solid", "Moss: a small plant that grows on damp surfaces and slowly breaks rock into soil.", {w=100, hc=20})
E("BRIK", 0xA84E3C, "solid", "Brick: a fired clay building block that insulates well and survives high temperature.", {w=100, hc=30, hi={1973, "!LAVA"}, note="Inert to ACID."})
E("CONC", 0x888888, "solid", "Concrete: set cement with sand and gravel. Hard, but acid eats the cement binder.", {w=100, hc=45, hi={1573, "LAVA"}})
E("BITH", 0x2B2B2B, "solid", "Bitumen: black sticky petroleum residue used for roads. It softens into UNOL when hot.", {w=100, hc=20, hi={400, "UNOL"}})
E("SCLK", 0x8A5A3B, "solid", "Soil clump: compacted, hardened earth. It soaks back into mud when wet.", {w=100, hc=35})
E("CHKP", 0xF3E8D0, "solid", "Meat: raw or cooked poultry and livestock meat. It spoils when warm and goes to RDGS.", {w=100, hc=25})
-- ---------- New agricultural elements (v12.2) ----------
-- Wheat
E("WHSE", 0xC6A04A, "powder", "Wheat seed: a grain that germinates in moist, fertile soil.", {w=65, hc=20})
E("WHSP", 0x78A64A, "solid", "Wheat sprout: a young wheat plant that grows into a mature wheat crop.", {w=100, hc=20})
E("WHET", 0xC9B34F, "solid", "Wheat crop: mature wheat that grows in fertile soil and can be harvested or eaten.", {w=100, hc=20})

-- Carrot
E("CRSE", 0xD98B36, "powder", "Carrot seed: a small seed that germinates in moist soil.", {w=55, hc=20})
E("CRSP", 0x5E963D, "solid", "Carrot sprout: a young carrot plant that develops into a mature carrot.", {w=100, hc=20})
E("CROT", 0xE87925, "powder", "Carrot: an edible root vegetable that can be eaten by farm animals.", {w=75, hc=25})

-- Apple
E("APSP", 0x8D663D, "solid", "Apple sapling: a young tree that grows in moist soil.", {w=100, hc=20})
E("APTR", 0x397B35, "solid", "Apple tree: a mature fruit tree that produces apples when it has water, soil and carbon dioxide.", {w=100, hc=20})
E("APPL", 0xD94336, "powder", "Apple: an edible fruit produced by an apple tree. It eventually spoils.", {w=70, hc=25})

-- Orange
E("ORSP", 0x8A653B, "solid", "Orange sapling: a young orange tree that grows in moist soil.", {w=100, hc=20})
E("ORTR", 0x347A32, "solid", "Orange tree: a mature fruit tree that produces oranges when it has water, soil and carbon dioxide.", {w=100, hc=20})
E("ORNG", 0xF28C28, "powder", "Orange: an edible citrus fruit produced by an orange tree. It eventually spoils.", {w=70, hc=25})

-- Banana
E("BNPL", 0x4B963B, "solid", "Banana plant: a tropical plant that grows in moist soil and produces bananas.", {w=100, hc=20})
E("BANA", 0xE9D35A, "powder", "Banana: an edible fruit produced by a banana plant. It eventually spoils.", {w=70, hc=25})

-- Sugar cane
E("SUGC", 0x69A84B, "solid", "Sugar cane: a tall tropical grass that grows in moist soil and can be squeezed into sugar.", {w=100, hc=20})

-- ---------- Gases (negative grav = rises) ----------
E("VAPR", 0xD9E9FF, "gas", "Water vapour (steam): water gas. It rises, and condenses back into WATR below 100°C.", {hc=42, temp=383, grav=-0.08, lo={372.9, "WATR"}})
E("OXYG", 0xA7D9FF, "gas", "Oxygen (O₂): the gas that fuels fire and respiration.", {grav=0.01, note="Flames burn hotter in OXYG, and HYDR, CH4, CO, ETHL and fuels explode when they burn beside it (the OXYG is used up)."})
E("HYDR", 0xD8F3FF, "gas", "Hydrogen (H₂): the lightest gas. It rises very quickly and burns to water vapour.", {grav=-0.12})
E("NITR", 0xB7C8E8, "gas", "Nitrogen (N₂): an almost inert gas that makes up most of air.", {grav=0.0, note="Smothers flames."})
E("CO2",  0xA5A5A5, "gas", "Carbon dioxide (CO₂): a heavy gas from burning and respiration. It sinks and smothers flames.", {grav=0.1})
E("CO",   0x777777, "gas", "Carbon monoxide (CO): a toxic, flammable gas from incomplete burning of carbon. It drifts slowly upward.", {grav=-0.02})
E("SULG", 0xE5D65B, "gas", "Sulfur gas (vapour and SO₂ fumes): a heavy, choking gas that makes acid rain.", {grav=0.15})
E("CH4",  0xD6E5B5, "gas", "Methane (CH₄): the main part of natural gas. A light, flammable gas that rises.", {grav=-0.06})
E("AMMO", 0xDDE6B5, "gas", "Ammonia (NH₃): a sharp-smelling gas that rises and dissolves very easily in water.", {grav=-0.05})
E("SMOK", 0x6B6B6B, "gas", "Smoke: soot, a little ash and hot gas from burning. It rises, drifts sideways and thins out, sometimes leaving flakes of ASH that fall back down.", {hc=20, grav=-0.07})

-- ---------- Special ----------
E("FIRE", 0xFF7A18, "fire", "Fire: a hot flame particle. It rises, heats and ignites flammable neighbours, and burns out into smoke or gas.", {temp=1100, menu="SC_EXPLOSIVE"})
E("COW",  0xE6E0D5, "animal", "Cow: a farm animal that wanders horizontally and eats plants.", {note="Eats PLNT, LEAF, VINE, MOSS when hungry and produces MILK and manure (FERT). Starves without food. Dies (becomes CHKP or ASH) from heat above 62°C or cold below -13°C, fire, LAVA, ACID, CO, SULG, AMMO, MERC, URAN and PLUT."})
E("SHEP", 0xE8E2D8, "animal", "Sheep: a farm animal that wanders horizontally and eats plants.", {note="Eats PLNT, LEAF, VINE, MOSS when hungry and grows WOOL and manure (FERT). Starves without food. Dies (becomes CHKP or ASH) from heat above 62°C or cold below -13°C, fire, LAVA, ACID, CO, SULG, AMMO, MERC, URAN and PLUT."})
E("CHKN", 0xE9D5A5, "animal", "Chicken: a bird that wanders horizontally, pecks seeds and lays eggs.", {note="Eats SEED and FOOD when hungry, lays EGG and leaves manure (FERT). Starves without food. Dies (becomes CHKP or ASH) from heat above 62°C or cold below -13°C, fire, LAVA, ACID, CO, SULG, AMMO, MERC, URAN and PLUT."})
E("SQZE", 0xFFFFFF, "solid", "Squeezer tool: select SQZE and hold the mouse on the canvas to squeeze the particles under the brush.", {w=100, hc=60, cond=true, menu="SC_SPECIAL", note="Brush size sets the squeezing area. A placed SQZE block squeezes touching particles. It cannot squeeze metals."})

-- ---------- v12.5 additions ----------
E("MVSL", 0x8C8C8C, "mover", "Moving solid: a solid block that falls with gravity, slides with velocity and is pushed by pressure. Pause the game, draw its shape, then use the property tool to set its ctype to a material.", {w=100, hc=60, menu="SC_SOLIDS", note="Shapes drawn while PAUSED are bonded and move together; shapes drawn while running are loose blocks. Colour comes from the ctype material (gray when none). It breaks other solids when its speed times its material strength beats their toughness (DMND never breaks)."})
E("CLNT", 0xD4AF37, "liquid", "Coolant: a golden heat-transfer fluid for cooling machines and reactors. Set its temperature with the property tool.", {w=33, hc=0, temp=293.15, note="Everything it touches is pulled toward its temperature, but nothing except the property tool can change the coolant's own temperature. Bright gold = very cold, dark gold = very hot."})
E("SIBE", 0x2A6BFF, "solid", "Sign box eraser: a blue eraser block that deletes any sign it touches.", {w=100, hc=20, menu="SC_SPECIAL", note="Place it over a sign's text box or its pointer point. It is not used up."})
E("CLUD", 0xFFFFFF, "cloud", "Cloud: a white gas cloud. Use the property tool to set its ctype to a powder or liquid and it will rain, snow or pour that material.", {w=2, hc=20, note="It absorbs VAPR (1 vapour = 1 drop) and then rains WATR, darkening as it fills. Solids and gases cannot be weather. Colour follows the weather."})
E("SNWT", 0x2F6BFF, "liquid", "Stained water: blue water that takes on the colour of staining materials (soil, rust, leaves, fruit...) that touch it.", {w=30, hc=28, cond=true, lo={273.15, "ICE"}, hi={373.15, "VAPR"}, note="Powders and mud dissolve into it; leaves, plants and wood stain it slowly without being used up. Stained water mixes colours and shares them with its neighbours. Freezing or boiling removes the colour."})

-- ============================================================
-- 2. COMBUSTION
-- ============================================================
local BURN = {
    SULF = {ign=505, flame=45, rate=15, out="SULG", ft=1000},
    SUCR = {ign=460, flame=30, rate=10, left="CARB", out="SMOK", ft=900},
    FOOD = {ign=520, flame=30, rate=10, left="ASH", out="SMOK", ft=900},
    WOOL = {ign=700, flame=18, rate=8, left="ASH", out="SMOK", ft=900},
    SPOR = {ign=500, flame=60, rate=20, left="ASH", out="SMOK", ft=900},
    FUNG = {ign=520, flame=30, rate=10, left="ASH", out="SMOK", ft=900},
    SEED = {ign=520, flame=30, rate=10, left="ASH", out="SMOK", ft=900},
    PLNT = {ign=500, flame=45, rate=12, left="ASH", out="SMOK", ft=1000},
    LEAF = {ign=480, flame=60, rate=15, left="ASH", out="SMOK", ft=1000},
    VINE = {ign=500, flame=45, rate=12, left="ASH", out="SMOK", ft=1000},
    MOSS = {ign=510, flame=30, rate=10, left="ASH", out="SMOK", ft=900},
    WOOD = {ign=573, flame=40, rate=8, left="ASH", alt="CARB", altp=35, out="SMOK", ft=1100},
    RDGS = {ign=520, flame=30, rate=10, left="ASH", out="SMOK", ft=900},
    CHKP = {ign=560, flame=30, rate=10, left="ASH", out="SMOK", ft=900},
    CARB = {ign=700, flame=10, rate=3, out={"CO2", "CO2", "CO"}, ft=1200},
    BITH = {ign=540, flame=25, rate=8, out="SMOK", ft=1100},
    ETHL = {ign=636, flame=90, rate=40, out="CO2", ft=1500, expl=1.0},
    DSEL = {ign=500, flame=25, rate=20, out="SMOK", ft=1400, expl=0.6},
    OIL  = {ign=600, flame=18, rate=15, out="SMOK", ft=1300, expl=0.5},
    COIL = {ign=500, flame=55, rate=20, out="SMOK", ft=1300, expl=0.8},
    KRSE = {ign=483, flame=40, rate=20, out="CO2", ft=1400, expl=0.8},
    UNOL = {ign=580, flame=20, rate=15, out="SMOK", ft=1300, expl=0.5},
    CH4  = {ign=810, flame=100, rate=50, out="CO2", ft=1700, expl=2.5, life=25},
    HYDR = {ign=773, flame=100, rate=60, out="VAPR", ft=1900, expl=3.0, life=20},
    CO   = {ign=880, flame=100, rate=40, out="CO2", ft=1500, expl=1.5, life=25},
        -- New agricultural elements
    WHSE = {ign=520, flame=30, rate=10, left="ASH", out="SMOK", ft=900},
    WHSP = {ign=500, flame=40, rate=12, left="ASH", out="SMOK", ft=950},
    WHET = {ign=500, flame=45, rate=12, left="ASH", out="SMOK", ft=1000},

    CRSE = {ign=520, flame=25, rate=10, left="ASH", out="SMOK", ft=900},
    CRSP = {ign=500, flame=35, rate=10, left="ASH", out="SMOK", ft=950},
    CROT = {ign=520, flame=30, rate=10, left="ASH", out="SMOK", ft=900},

    APSP = {ign=573, flame=35, rate=10, left="ASH", alt="CARB", altp=25, out="SMOK", ft=1050},
    APTR = {ign=573, flame=40, rate=10, left="ASH", alt="CARB", altp=35, out="SMOK", ft=1100},
    APPL = {ign=520, flame=35, rate=12, left="ASH", out="SMOK", ft=900},

    ORSP = {ign=573, flame=35, rate=10, left="ASH", alt="CARB", altp=25, out="SMOK", ft=1050},
    ORTR = {ign=573, flame=40, rate=10, left="ASH", alt="CARB", altp=35, out="SMOK", ft=1100},
    ORNG = {ign=520, flame=35, rate=12, left="ASH", out="SMOK", ft=900},

    BNPL = {ign=500, flame=40, rate=12, left="ASH", out="SMOK", ft=1000},
    BANA = {ign=520, flame=35, rate=12, left="ASH", out="SMOK", ft=900},

    SUGC = {ign=500, flame=45, rate=12, left="ASH", out="SMOK", ft=1000},
}

-- ============================================================
-- 3. REACTION RULES
-- ============================================================
local WATERS = {"WATR", "ICEW", "DSWR", "SLTW"}
local DAMP   = {"WATR", "MUD", "ICEW", "DSWR"}
local NOX    = {"ZINC", "OIL", "DSEL", "KRSE", "COIL", "UNOL"}   -- protect iron from rust

local function cat(a, b)
    local r = {}
    for _, v in ipairs(a) do r[#r + 1] = v end
    for _, v in ipairs(b) do r[#r + 1] = v end
    return r
end

local oreRules = {
    {w="CARB", tmin=1050, s="IRON", o="x", g={"CO2"}, p=4},
    {w="HYDR", tmin=650,  s="IRON", o="VAPR", p=5},
    {w="CO",   tmin=800,  s="IRON", o="CO2", p=5},
    {w="ALUM", tmin=1100, s="IRON", o="ALOX", g={"FIRE"}, dS=900, pr=1.5, p=40},   -- thermite
}

local RULES = {}

RULES.IROX = oreRules
RULES.RUST = cat(oreRules, {{w="WATR", o="DSWR", p=0.4}})

RULES.SALT = {
    {w={"WATR", "DSWR"}, s="x", o="SLTW", p=6},
    {w="ICE", s="x", o="SLTW", oT=266, p=8},
    {w={"PLNT", "LEAF", "VINE", "MOSS"}, o="RDGS", p=0.8},
}
RULES.SUCR = {
    {w=WATERS, s="x", p=6},
    {w="FUNG", n=WATERS, tmin=285, tmax=320, s="ETHL", g={"CO2"}, p=3},
}
RULES.BICA = {
    {tmin=360, s="x", g={"CO2", "VAPR"}, p=4},
    {w="FIRE", s="CO2", o="x", p=40},
    {w=WATERS, s="x", p=2},
}
RULES.SOIL = {
    {w={"WATR", "DSWR", "ICEW"}, s="MUD", o="x", p=3},
    {w="FERT", s="FRSL", o="x", p=3},
    {w="RDGS", s="FRSL", o="x", p=1.5},
    {w="ASH",  s="FRSL", o="x", p=1},
    {w="AMMO", s="FRSL", o="x", p=2},
}
RULES.FRSL = {
    {w={"WATR", "DSWR"}, s="SOIL", o="DSWR", p=0.3},
}
RULES.SEED = {
    {w="FRSL", n=DAMP, tmin=280, tmax=312, s="PLNT", p=3},
    {w="MUD",  tmin=280, tmax=312, s="PLNT", p=1.2},
    {w="SOIL", n=DAMP, tmin=280, tmax=312, s="PLNT", p=0.8},
    {w="SLTW", s="RDGS", p=0.4},
}
RULES.PLNT = {
    {w="CO2", n={"WATR", "MUD", "SOIL", "FRSL"}, tmin=278, tmax=315, o="OXYG", p=2.5},
    {w="WATR", n={"FRSL"}, tmin=280, tmax=312, o="x", g={"PLNT", "PLNT", "LEAF"}, one=true, gu=true, p=2.5},
    {w="WATR", n={"SOIL", "MUD"}, tmin=280, tmax=312, o="x", g={"PLNT", "PLNT", "LEAF"}, one=true, gu=true, p=1},
    {w="FERT", tmin=280, tmax=312, o="x", g={"PLNT"}, gu=true, p=3},
    {w="SULG", s="RDGS", p=1.5},
    {w="SLTW", s="RDGS", p=0.4},
    {w="MERC", s="RDGS", p=0.5},
    {tmax=262, s="RDGS", p=1.5},
    {tmin=330, s="RDGS", p=2},
}
RULES.LEAF = {
    {w="CO2", n={"WATR", "MUD", "SOIL", "FRSL"}, tmin=278, tmax=315, o="OXYG", p=3},
    {n=DAMP, tmin=285, tmax=310, g={"SEED"}, gu=true, p=0.05},
    {w="SULG", s="RDGS", p=1.5},
    {w="SLTW", s="RDGS", p=0.4},
    {tmax=262, s="RDGS", p=1.5},
    {tmax=275, s="RDGS", p=0.3},
    {tmin=330, s="RDGS", p=2},
}
RULES.VINE = {
    {w="WATR", n={"WOOD", "ROCK", "STON", "BRIK", "CONC", "CRSK", "SCLK", "SOIL", "FRSL"}, tmin=282, tmax=312, o="x", g={"VINE"}, p=0.8},
    {w="CO2", n={"WATR", "MUD", "SOIL", "FRSL"}, tmin=278, tmax=315, o="OXYG", p=2},
    {w="SULG", s="RDGS", p=1.5},
    {tmax=262, s="RDGS", p=1.5},
    {tmin=330, s="RDGS", p=2},
}
RULES.MOSS = {
    {w="WATR", n={"ROCK", "STON", "SOIL", "MUD", "WOOD", "BRIK", "CONC", "SCLK"}, tmin=275, tmax=305, o="x", g={"MOSS"}, p=0.5},
    {w="CO2", n={"WATR", "MUD", "SOIL", "FRSL"}, tmin=275, tmax=312, o="OXYG", p=1.5},
    {w="ROCK", n={"WATR"}, o="SOIL", p=0.03},
    {w="STON", n={"WATR"}, o="SOIL", p=0.05},
    {w="SULG", s="RDGS", p=1.5},
    {tmin=325, s="RDGS", p=2},
}
RULES.ASH = {{w={"WATR", "DSWR"}, s="x", o="DSWR", p=1.5}}
RULES.FERT = {
    {w={"WATR", "DSWR", "ICEW"}, s="x", o="DSWR", p=3},
    {w="MUD", s="x", o="FRSL", p=2},
    {tmin=550, s="x", g={"NITR", "VAPR"}, dS=40, p=3},
}
RULES.FOOD = {{tmin=298, tmax=340, s="RDGS", p=0.03}}
RULES.FUNG = {
    {w="FOOD", n=DAMP, tmin=278, tmax=315, o="FUNG", p=2.5},
    {w="RDGS", n=DAMP, tmin=278, tmax=315, o="FUNG", p=1.5},
    {w="WOOD", n=DAMP, tmin=278, tmax=315, o="RDGS", g={"SPOR"}, p=0.3},
    {w={"PLNT", "LEAF"}, n=DAMP, tmin=278, tmax=315, o="RDGS", p=0.3},
    {w="WOOL", n=DAMP, tmin=278, tmax=315, o="RDGS", p=0.2},
    {w="CHKP", n=DAMP, tmin=278, tmax=330, o="RDGS", g={"SPOR"}, p=1.5},
    {n=DAMP, tmin=283, tmax=312, g={"SPOR"}, p=0.15},
    {tmin=330, s="RDGS", p=3},
}
RULES.SPOR = {
    {w="FOOD", n=DAMP, tmin=278, tmax=315, s="FUNG", p=2},
    {w="RDGS", n=DAMP, tmin=278, tmax=315, s="FUNG", p=2},
    {w="WOOD", n=DAMP, tmin=278, tmax=315, s="FUNG", p=0.5},
    {w={"SOIL", "MUD"}, n=DAMP, tmin=278, tmax=315, s="FUNG", p=0.3},
}
RULES.RDGS = {
    {w="MUD", s="SOIL", g={"CH4"}, p=0.15},
    {w={"WATR", "DSWR"}, s="SOIL", g={"CH4", "CO2"}, one=true, p=0.12},
    {tmin=285, s="SOIL", g={"CO2"}, p=0.04},
}
RULES.CEMT = {{w={"WATR", "DSWR", "SLTW"}, s="CONC", o="x", dS=4, p=3}}
RULES.SAND = {{w="BICA", tmin=1200, s="GLAS", o="x", g={"CO2"}, p=5}}
RULES.WHSD = RULES.SAND
RULES.CLAY = {{w={"WATR", "DSWR"}, s="MUD", o="x", p=2.5}}
RULES.STON = {{tmin=1100, s="CEMT", g={"CO2"}, p=2}}
RULES.GLAS = {{w={"WATR", "ICEW", "ICE"}, tmin=520, s="SAND", p=6}}
RULES.BITH = {{w={"DSEL", "KRSE"}, s="UNOL", o="x", p=1.5}}
RULES.COIL = {{tmin=420, s="UNOL", g={"KRSE", "CH4"}, p=2}}
RULES.UNOL = {
    {tmin=600, s="CARB", g={"DSEL", "CH4"}, p=1.5},
    {tmax=280, s="BITH", p=0.4},
}
RULES.ETHL = {
    {tmin=352, s="x", p=8},
    {w=WATERS, s="x", p=1.2},
    {w={"FUNG", "SPOR"}, o="RDGS", p=3},
    {w="ICE", s="x", o="WATR", oT=275, p=2},
}
RULES.MERC = {
    {tmin=630, s="x", p=3},
    {w="ALUM", o="ALOX", p=0.8},
    {w="GOLD", o="MERC", p=0.3},
    {w="SILV", o="MERC", p=0.2},
    {w="TIN",  o="MERC", p=0.4},
    {w="ZINC", o="MERC", p=0.3},
    {w="LEAD", o="MERC", p=0.3},
    {w={"PLNT", "LEAF", "VINE", "MOSS"}, o="RDGS", p=0.3},
}
RULES.ACID = {
    {w={"IRON", "STEL"}, s="DSWR", o="x", g={"HYDR"}, dT=8, p=6},
    {w="ZINC", s="SLTW", o="x", g={"HYDR"}, dT=8, p=8},
    {w="ALUM", s="SLTW", o="x", g={"HYDR"}, dT=8, p=3},
    {w="TIN",  s="SLTW", o="x", g={"HYDR"}, p=1.2},
    {w="COPR", tmin=400, s="DSWR", o="x", g={"SULG"}, p=4},
    {w="SILV", tmin=400, s="DSWR", o="x", g={"SULG"}, p=1.5},
    {w="BRAS", s="SLTW", o="COPR", g={"HYDR"}, p=3},
    {w="BRNZ", s="SLTW", o="COPR", g={"HYDR"}, p=1.5},
    {w={"IROX", "RUST", "PATI"}, s="DSWR", o="x", p=8},
    {w="BICA", s="SLTW", o="x", g={"CO2"}, dT=6, p=30},
    {w="STON", s="SLTW", o="x", g={"CO2"}, p=4},
    {w="CONC", s="WATR", o="GRVL", p=1.5},
    {w="SUCR", s="WATR", o="CARB", g={"VAPR"}, dS=40, p=20},
    {w={"WOOD", "PLNT", "LEAF", "VINE", "MOSS", "FOOD"}, s="WATR", o="CARB", p=4},
    {w={"WOOL", "FUNG", "SPOR", "CHKP"}, s="WATR", o="RDGS", p=4},
    {w="EGG", s="WATR", o="FOOD", p=5},
    {w="WATR", s="WATR", dT=12, p=1.5},
}
RULES.PERO = {
    {tmin=345, s="WATR", g={"OXYG"}, dS=15, p=6},
    {w={"IROX", "RUST", "SILV", "MERC"}, s="WATR", g={"OXYG"}, dS=20, p=12},
    {w={"COPR", "IRON", "PLNT", "LEAF"}, s="WATR", g={"OXYG"}, p=2},
    {w={"FUNG", "SPOR"}, s="WATR", o="RDGS", g={"OXYG"}, p=8},
}
RULES.LAVA = {
    {w={"WATR", "ICEW", "DSWR", "SLTW", "ICE"}, s="ROCK", o="VAPR", dS=-450, dO=250, pr=2, p=25},
    {w={"SAND", "WHSD"}, o="GLAS", p=3},
    {w="CLAY", o="CERA", p=3},
    {w="SOIL", o="SCLK", p=3},
}
RULES.MUD = {
    {tmin=450, s="SCLK", g={"VAPR"}, p=4},
    {tmin=335, s="SOIL", g={"VAPR"}, p=2},
    {w="WATR", s="DSWR", p=0.4},
}
RULES.SCLK = {{w={"WATR", "DSWR"}, s="MUD", o="x", p=0.6}}
RULES.MILK = {
    {w="ACID", s="FOOD", o="WATR", p=15},
    {w="FUNG", tmin=290, tmax=315, s="FOOD", p=2},
    {tmin=303, tmax=330, s="FOOD", p=0.03},
}
RULES.SLTW = {{tmin=374, s="VAPR", g={"SALT"}, p=25}}
RULES.DSWR = {
    {w={"SAND", "WHSD", "GRVL", "CRSK", "CARB", "WOOL"}, s="WATR", p=4},
    {tmin=374, s="VAPR", g={"SOIL"}, p=25},
    {s="WATR", p=0.15},   -- v12.6.1: settling no longer drops SOIL (it turned into MUD)
}
-- Smoke: mostly just thins out, but a little of it leaves ASH flakes that fall.
RULES.SMOK = {
    {s="x", g={"ASH"}, p=0.12},
    {s="x", p=0.30},
}
RULES.CARB = {
    {w="CO2",  tmin=1170, s="CO", o="CO", p=5},
    {w="VAPR", tmin=1000, s="CO", o="HYDR", p=6},
}
RULES.IRON = {
    {w="WATR", nx=NOX, s="RUST", p=0.04},
    {w="SLTW", nx=NOX, s="RUST", p=0.2},
    {w="OXYG", tmin=900, s="IROX", o="x", dS=250, p=3},
    {w="VAPR", tmin=800, s="IROX", g={"HYDR"}, p=3},
    {w="CARB", tmin=1200, s="STEL", o="x", p=3},
}
RULES.STEL = {
    {w="WATR", nx=NOX, s="RUST", p=0.015},
    {w="SLTW", nx=NOX, s="RUST", p=0.07},
    {w="OXYG", tmin=1000, s="IROX", o="x", dS=200, p=2},
    {w="VAPR", tmin=900, s="IROX", g={"HYDR"}, p=2},
}
RULES.COPR = {
    {w="WATR", s="PATI", p=0.03},
    {w="SLTW", s="PATI", p=0.12},
    {w="OXYG", tmin=500, s="PATI", o="x", p=2},
    {w="TIN",  tmin=470, s="BRNZ", o="BRNZ", p=4},
    {w="ZINC", tmin=620, s="BRAS", o="BRAS", p=4},
}
RULES.BRAS = {{w="WATR", s="PATI", p=0.012}, {w="SLTW", s="PATI", p=0.05}}
RULES.BRNZ = {{w="SLTW", s="PATI", p=0.03}}
RULES.PATI = {{w="CARB", tmin=1000, s="COPR", o="x", g={"CO2"}, p=3}}
RULES.ALUM = {
    {w="SLTW", s="ALOX", p=0.05},
    {w="OXYG", tmin=1000, s="ALOX", o="x", dS=300, p=3},
}
RULES.EGG = {
    {tmin=300, tmax=316, s="CHKN", p=0.15},
    {w="CHKN", tmin=283, tmax=316, s="CHKN", p=0.5},
    {tmin=335, s="FOOD", p=6},
}
RULES.CHKP = {{tmin=298, tmax=340, s="RDGS", p=0.04}}
RULES.FIRE = {
    {w={"WATR", "DSWR", "SLTW", "ICEW"}, s="x", o="VAPR", p=30},
    {w="ICE", s="x", o="WATR", oT=275, p=25},
    {w={"CO2", "NITR"}, s="x", p=12},
    {w={"SAND", "WHSD", "SOIL", "ASH", "GRVL", "CRSK", "CEMT"}, s="x", p=8},
    {w="OXYG", o="x", dS=120, p=10},
}
RULES.SULG = {
    {w={"WATR", "DSWR", "ICEW"}, s="x", o="ACID", p=2.5},
    {w="VAPR", s="x", o="ACID", p=4},
    {w="AMMO", s="x", o="FERT", p=2},
}
RULES.CH4  = {{w="VAPR", tmin=1000, s="CO", o="HYDR", p=4}}
RULES.CO   = {{w="VAPR", tmin=670, s="CO2", o="HYDR", p=6}}
RULES.NITR = {{w="HYDR", n={"IRON", "STEL"}, tmin=670, s="AMMO", o="AMMO", p=3}}   -- Haber process
RULES.AMMO = {
    {w={"WATR", "DSWR", "ICEW"}, s="x", p=4},
    {w="ACID", s="FERT", o="x", p=40},
    {w="SOIL", s="x", o="FRSL", p=2},
    {w="CO2", tmin=420, s="FERT", o="x", p=3},
    {w="OXYG", tmin=1000, fl=true, s="NITR", o="VAPR", dS=200, p=10},
    {w={"COPR", "BRAS"}, n={"WATR", "VAPR"}, o="PATI", p=0.2},
    {tmin=800, s="NITR", g={"HYDR"}, p=3},
}


-- ============================================================
-- New agricultural reactions (v12.2)
-- ============================================================

-- Wheat
RULES.WHSE = {
    {w={"SOIL", "FRSL"}, n=DAMP, tmin=280, tmax=312, s="WHSP", p=2.5},
    {w="SLTW", s="RDGS", p=0.5},
    {w="ACID", s="RDGS", p=2},
}
RULES.WHSP = {
    {w="WATR", n={"SOIL", "FRSL", "MUD"}, tmin=280, tmax=315, s="WHET", p=0.8},
    {w="CO2", n=DAMP, tmin=278, tmax=315, o="OXYG", p=2},
    {w="SULG", s="RDGS", p=1.5},
    {w="SLTW", s="RDGS", p=0.5},
    {w="ACID", s="RDGS", p=2},
    {tmin=330, s="RDGS", p=2},
}
RULES.WHET = {
    {w="CO2", n={"WATR", "SOIL", "FRSL"}, tmin=278, tmax=315, o="OXYG", p=3},
    {w="SULG", s="RDGS", p=1.5},
    {w="SLTW", s="RDGS", p=0.5},
    {w="ACID", s="RDGS", p=2},
    {tmin=330, s="RDGS", p=2},
}

-- Carrot
RULES.CRSE = {
    {w={"SOIL", "FRSL"}, n=DAMP, tmin=280, tmax=312, s="CRSP", p=2.5},
    {w="SLTW", s="RDGS", p=0.5},
    {w="ACID", s="RDGS", p=2},
}
RULES.CRSP = {
    {w="WATR", n={"SOIL", "FRSL", "MUD"}, tmin=280, tmax=315, s="CROT", p=0.8},
    {w="CO2", n=DAMP, tmin=278, tmax=315, o="OXYG", p=2},
    {w="SULG", s="RDGS", p=1.5},
    {w="SLTW", s="RDGS", p=0.5},
    {w="ACID", s="RDGS", p=2},
    {tmin=330, s="RDGS", p=2},
}
RULES.CROT = {
    {tmin=330, s="RDGS", p=0.08},
    {w="ACID", s="RDGS", p=3},
}

-- Apple trees
RULES.APSP = {
    {w="WATR", n={"SOIL", "FRSL", "MUD"}, tmin=280, tmax=315, s="APTR", p=0.5},
    {w="SULG", s="RDGS", p=1.5},
    {w="SLTW", s="RDGS", p=0.5},
    {w="ACID", s="RDGS", p=2},
    {tmin=330, s="RDGS", p=2},
}
RULES.APTR = {
    {w="CO2", n={"WATR", "SOIL", "FRSL"}, tmin=278, tmax=315, o="OXYG", g={"APPL"}, p=0.8},
    {w="SULG", s="RDGS", p=1.5},
    {w="SLTW", s="RDGS", p=0.5},
    {w="ACID", s="RDGS", p=2},
    {tmin=330, s="RDGS", p=2},
}
RULES.APPL = {
    {tmin=330, s="RDGS", p=0.08},
    {w="ACID", s="RDGS", p=3},
}

-- Orange trees
RULES.ORSP = {
    {w="WATR", n={"SOIL", "FRSL", "MUD"}, tmin=280, tmax=315, s="ORTR", p=0.5},
    {w="SULG", s="RDGS", p=1.5},
    {w="SLTW", s="RDGS", p=0.5},
    {w="ACID", s="RDGS", p=2},
    {tmin=330, s="RDGS", p=2},
}
RULES.ORTR = {
    {w="CO2", n={"WATR", "SOIL", "FRSL"}, tmin=278, tmax=315, o="OXYG", g={"ORNG"}, p=0.8},
    {w="SULG", s="RDGS", p=1.5},
    {w="SLTW", s="RDGS", p=0.5},
    {w="ACID", s="RDGS", p=2},
    {tmin=330, s="RDGS", p=2},
}
RULES.ORNG = {
    {tmin=330, s="RDGS", p=0.08},
    {w="ACID", s="RDGS", p=3},
}

-- Banana plant
RULES.BNPL = {
    {w="WATR", n={"SOIL", "FRSL", "MUD"}, tmin=280, tmax=315, g={"BANA"}, p=0.7},
    {w="CO2", n=DAMP, tmin=278, tmax=315, o="OXYG", p=2},
    {w="SULG", s="RDGS", p=1.5},
    {w="SLTW", s="RDGS", p=0.5},
    {w="ACID", s="RDGS", p=2},
    {tmin=330, s="RDGS", p=2},
}
RULES.BANA = {
    {tmin=330, s="RDGS", p=0.08},
    {w="ACID", s="RDGS", p=3},
}

-- Sugar cane
RULES.SUGC = {
    {w="WATR", n={"SOIL", "FRSL", "MUD"}, tmin=280, tmax=315, g={"SUGC"}, p=0.4},
    {w="CO2", n=DAMP, tmin=278, tmax=315, o="OXYG", p=2},
    {w="SULG", s="RDGS", p=1.5},
    {w="SLTW", s="RDGS", p=0.5},
    {w="ACID", s="RDGS", p=2},
    {tmin=330, s="RDGS", p=2},
}


-- Squeezer recipes
local SQZ = {
    MUD  = {out="SOIL", g={"WATR"}, p=25},
    SOIL = {out="SCLK", p=8},
    FRSL = {out="SCLK", p=8},
    CLAY = {out="BRIK", p=6},
    SEED = {out="OIL", p=15},
    PLNT = {out="RDGS", g={"WATR"}, p=15},
    LEAF = {out="RDGS", g={"WATR"}, p=15},
    VINE = {out="RDGS", g={"WATR"}, p=15},
    MOSS = {out="RDGS", g={"WATR"}, p=15},
    EGG  = {out="FOOD", p=40},
    ICE  = {out="WATR", t=274.5, p=10},
    ROCK = {out="GRVL", p=5},
    STON = {out="CRSK", p=5},
    CRSK = {out="GRVL", p=4},
    GRVL = {out="SAND", p=4},
    CONC = {out="GRVL", p=3},
    GLAS = {out="SAND", p=3},
        -- New agricultural recipes
    WHSE = {out="FOOD", p=25},
    WHSP = {out="FOOD", p=15},
    WHET = {out="FOOD", p=35},
    CRSE = {out="FOOD", p=25},
    CRSP = {out="FOOD", p=15},
    CROT = {out="FOOD", p=40},
    APPL = {out="FOOD", p=45},
    ORNG = {out="FOOD", p=45},
    BANA = {out="FOOD", p=45},
    SUGC = {out="SUCR", p=35},
    APSP = {out="RDGS", p=15},
    APTR = {out="APPL", p=30},
    ORSP = {out="RDGS", p=15},
    ORTR = {out="ORNG", p=30},
    BNPL = {out="BANA", p=30},
}

-- Animals
local ANIM_SRC = {
    COW = {
        food={"PLNT", "LEAF", "VINE", "MOSS", "WHET", "CROT", "APPL", "ORNG", "BANA"},
        prod="MILK", prodp=35
    },
    SHEP = {
        food={"PLNT", "LEAF", "VINE", "MOSS", "WHET", "CROT", "APPL", "ORNG", "BANA"},
        prod="WOOL", prodp=30
    },
    CHKN = {
        food={"SEED", "FOOD", "WHSE", "CRSE", "APPL", "ORNG", "BANA"},
        prod="EGG", prodp=25
    },
}

local HAZARDS = {   -- {name, chance % per frame, becomes}
    {"CO", 4, "CHKP"}, {"SULG", 2, "CHKP"}, {"AMMO", 1.5, "CHKP"}, {"ACID", 40, "CHKP"},
    {"MERC", 1, "CHKP"}, {"URAN", 0.5, "CHKP"}, {"PLUT", 1, "CHKP"},
    {"LAVA", 100, "ASH"}, {"FIRE", 30, "ASH"}, {"!PLSM", 100, "ASH"},
}

-- Gases that must go UP: extra upward push per frame (on top of negative Gravity).
local RISE_SRC = {
    SMOK = 0.06, VAPR = 0.06, HYDR = 0.10, CH4 = 0.06, AMMO = 0.05, CO = 0.02, FIRE = 0.08,
}
-- Sideways wobble so smoke and steam drift instead of rising in a straight line.
local DRIFT_SRC = { SMOK = 0.12, VAPR = 0.06, CH4 = 0.04, AMMO = 0.04 }

-- ============================================================
-- 4. ALLOCATE ELEMENTS
-- ============================================================
local T = {}            -- custom ID  -> particle type number
local ISCUSTOM = {}     -- ID -> true
for _, d in ipairs(ELIST) do
    local ok, t = pcall(EL.allocate, GROUP, d.id)
    if not ok or not t or t < 0 then
        t = EL[GROUP .. "_PT_" .. d.id]
    end
    if t then
        T[d.id] = t
        ISCUSTOM[d.id] = true
    else
        print("Mack_New_Elements: could not allocate " .. d.id)
    end
end

local function std(n) return EL["DEFAULT_PT_" .. n] end
local BI = {NEUT = std("NEUT"), FIRE = std("FIRE"), PLSM = std("PLSM"), LAVA = std("LAVA")}

local ALIAS = {
    WATR="WATR", SALT="SALT", SAND="SAND", FIRE="FIRE", ACID="ACID", OXYG="O2", HYDR="H2",
    CO2="CO2", MERC="MERC", OIL="OIL", WOOD="WOOD", PLNT="PLNT", ICE="ICEI", SLTW="SLTW",
    VAPR="WTRV", SMOK="SMKE", GLAS="GLAS", GOLD="GOLD", IRON="IRON",
    TITA="TTAN", URAN="URAN", PLUT="PLUT", BRIK="BRCK", STON="STNE", VINE="VINE",
    LAVA="LAVA", NITR="NITR", CH4="METH", ASH="BASH",
}

local function typeIds(name)
    local ids = {}
    if name:sub(1, 1) == "!" then
        local b = BI[name:sub(2)] or std(name:sub(2))
        if b then ids[1] = b end
        return ids
    end
    if T[name] then ids[#ids + 1] = T[name] end
    local a = ALIAS[name]
    if a then
        local b = std(a)
        if b then ids[#ids + 1] = b end
    end
    return ids
end

local function resultId(name)
    if name == nil or name == "x" then return name end
    if name:sub(1, 1) == "!" then return BI[name:sub(2)] or std(name:sub(2)) end
    return T[name]
end

-- ============================================================
-- 5. DESCRIPTIONS (generated from the real rules)
-- ============================================================
local function nm(n) if n:sub(1, 1) == "!" then return "std " .. n:sub(2) end return n end
local function listOf(v) if type(v) == "table" then return v end return {v} end
local function degC(K) return floor(K - 273.15 + 0.5) end
local function joinNames(v, limit)
    local l, out = listOf(v), {}
    for k = 1, #l do
        if limit and k > limit then out[#out + 1] = "..."; break end
        out[#out + 1] = nm(l[k])
    end
    return table.concat(out, "/")
end
local function sortedKeys(t)
    local k = {}
    for key in pairs(t) do k[#k + 1] = key end
    table.sort(k)
    return k
end

local function prodNames(r)
    local out, seenN = {}, {}
    local function add(n) if n and n ~= "x" and not seenN[n] then seenN[n] = true; out[#out + 1] = n end end
    add(r.s); add(r.o)
    if r.g then for _, n in ipairs(r.g) do add(n) end end
    return out
end

local function condText(r)
    local c = {}
    if r.tmin then c[#c + 1] = (r.fl and "flame or " or "") .. "≥" .. degC(r.tmin) .. "°C" end
    if r.tmax then c[#c + 1] = "≤" .. degC(r.tmax) .. "°C" end
    if r.n then c[#c + 1] = "near " .. joinNames(r.n, 3) end
    if r.nx then c[#c + 1] = "unless near " .. joinNames(r.nx, 3) end
    if #c > 0 then return " [" .. table.concat(c, ", ") .. "]" end
    return ""
end

local function resultText(r, fromSrc, otherName)
    local res = {}
    for _, n in ipairs(prodNames(r)) do res[#res + 1] = nm(n) end
    if #res > 0 then return table.concat(res, "+") end
    local sx, ox = (r.s == "x"), (r.o == "x")
    if sx and ox then return "both used up" end
    if fromSrc then
        if sx then return "is used up" end
        if ox then return otherName .. " consumed" end
    else
        if ox then return "is used up" end
        if sx then return otherName .. " consumed" end
    end
    return "heat/pressure only"
end

local lines, made = {}, {}
local function addTo(tbl, id, text)
    if not ISCUSTOM[id] then return end
    local l = tbl[id]
    if not l then l = {}; tbl[id] = l end
    for k = 1, #l do if l[k] == text then return end end
    l[#l + 1] = text
end

for _, src in ipairs(sortedKeys(RULES)) do
    for _, r in ipairs(RULES[src]) do
        local cond = condText(r)
        if r.w then
            local wl = joinNames(r.w, 4)
            addTo(lines, src, src .. "+" .. wl .. " → " .. resultText(r, true, nm(listOf(r.w)[1])) .. cond)
            for _, wn in ipairs(listOf(r.w)) do
                addTo(lines, wn, wn .. "+" .. src .. " → " .. resultText(r, false, src) .. cond)
            end
        else
            local when = cond ~= "" and ("when" .. cond:gsub("[%[%]]", "")) or "over time"
            addTo(lines, src, when .. " → " .. resultText(r, true, ""))
        end
        for _, pn in ipairs(prodNames(r)) do
            local how = r.w and (src .. "+" .. joinNames(r.w, 3)) or (src .. (r.tmin and " heated" or " decaying"))
            addTo(made, pn, how)
        end
    end
end

for _, id in ipairs(sortedKeys(BURN)) do
    local b = BURN[id]
    local outs = {}
    local function add(n) if n then outs[#outs + 1] = n end end
    add(b.left); add(b.alt)
    for _, o in ipairs(listOf(b.out)) do
        local dup = false
        for _, e in ipairs(outs) do if e == o then dup = true end end
        if not dup then outs[#outs + 1] = o end
    end
    addTo(lines, id, "burns (≥" .. degC(b.ign) .. "°C or touching flame) → FIRE then " .. table.concat(outs, "+"))
    for _, o in ipairs(outs) do addTo(made, o, "burning " .. id) end
end

for _, id in ipairs(sortedKeys(SQZ)) do
    local q = SQZ[id]
    local res = {q.out}
    if q.g then for _, n in ipairs(q.g) do res[#res + 1] = n end end
    addTo(lines, id, "squeezed → " .. table.concat(res, "+"))
    for _, n in ipairs(res) do addTo(made, n, "squeezing " .. id) end
end

for _, d in ipairs(ELIST) do
    if d.hi then
        addTo(lines, d.id, "above " .. degC(d.hi[1]) .. "°C → " .. nm(d.hi[2]))
        addTo(made, d.hi[2], d.id .. " above " .. degC(d.hi[1]) .. "°C")
    end
    if d.lo then
        addTo(lines, d.id, "below " .. degC(d.lo[1]) .. "°C → " .. nm(d.lo[2]))
        addTo(made, d.lo[2], d.id .. " below " .. degC(d.lo[1]) .. "°C")
    end
end

local function buildDescription(d)
    local parts = {d.text}
    local L, M = lines[d.id], made[d.id]
    if L and #L > 0 then parts[#parts + 1] = "Does: " .. table.concat(L, "; ") .. "." end
    if M and #M > 0 then parts[#parts + 1] = "Made by: " .. table.concat(M, "; ") .. "." end
    if d.note then parts[#parts + 1] = d.note end
    return table.concat(parts, " ")
end

-- ============================================================
-- 6. DEFINE ELEMENTS
-- ============================================================
local KIND = {
    powder = {Properties=TP, Advection=0.7, AirDrag=0.02, AirLoss=0.96, Loss=0.94, Collision=0.0, Gravity=0.4, Diffusion=0.0, HotAir=0.0, Falldown=1, Hardness=30, Weight=85, HeatConduct=70, menu="SC_POWDERS"},
    liquid = {Properties=TL, Advection=0.6, AirDrag=0.01, AirLoss=0.98, Loss=0.95, Collision=0.0, Gravity=0.1, Diffusion=0.0, HotAir=0.0, Falldown=2, Hardness=20, Weight=30, HeatConduct=29, menu="SC_LIQUID"},
    solid  = {Properties=TS, Advection=0.0, AirDrag=0.0, AirLoss=0.90, Loss=0.0, Collision=0.0, Gravity=0.0, Diffusion=0.0, HotAir=0.0, Falldown=0, Hardness=1, Weight=100, HeatConduct=100, menu="SC_SOLIDS"},
    gas    = {Properties=TG, Advection=1.0, AirDrag=0.01, AirLoss=0.99, Loss=0.30, Collision=-0.1, Gravity=0.0, Diffusion=0.75, HotAir=0.001, Falldown=0, Hardness=0, Weight=1, HeatConduct=42, menu="SC_GAS"},
    fire   = {Properties=TG, Advection=0.9, AirDrag=0.04, AirLoss=0.97, Loss=0.20, Collision=0.0, Gravity=-0.1, Diffusion=0.0, HotAir=0.001, Falldown=1, Hardness=0, Weight=2, HeatConduct=88, menu="SC_SPECIAL"},
    animal = {Properties=TP, Advection=0.0, AirDrag=0.0, AirLoss=0.95, Loss=0.5, Collision=0.0, Gravity=0.5, Diffusion=0.0, HotAir=0.0, Falldown=0, Hardness=0, Weight=95, HeatConduct=40, menu="SC_SPECIAL"},
    mover  = {Properties=TP, Advection=0.4, AirDrag=0.01, AirLoss=0.95, Loss=0.90, Collision=0.0, Gravity=0.3, Diffusion=0.0, HotAir=0.0, Falldown=0, Hardness=0, Weight=100, HeatConduct=60, menu="SC_SOLIDS"},
    cloud  = {Properties=TG, Advection=0.6, AirDrag=0.01, AirLoss=0.99, Loss=0.30, Collision=-0.1, Gravity=0.0, Diffusion=0.20, HotAir=0.0, Falldown=0, Hardness=0, Weight=2, HeatConduct=20, menu="SC_GAS"},
}

local INIT = {}
local SPAWNMIN = {}
if T.VAPR then SPAWNMIN[T.VAPR] = 380 end

-- v12.6: water-type liquids let neutrons through (like the standard WATR)
local NEUT_PASS = {WATR=true, SLTW=true, DSWR=true, ICEW=true, SNWT=true, CLNT=true, PERO=true}

local function defineAll()
    for _, d in ipairs(ELIST) do
        local t = T[d.id]
        if t then
            local base = KIND[d.kind]
            local def = {}
            for k, v in pairs(base) do def[k] = v end
            def.Name = d.id
            def.Colour = d.col
            def.Description = buildDescription(d)
            def.MenuVisible = 1
            def.Enabled = 1
            def.MenuSection = EL[d.menu or base.menu] or EL.SC_SPECIAL
            def.menu = nil
            def.Flammable = 0
            def.Explosive = 0
            def.Meltable = 0
            if d.w then def.Weight = d.w end
            if d.hc then def.HeatConduct = d.hc end
            if d.grav then def.Gravity = d.grav end
            local props = def.Properties
            if d.cond then props = props + PCOND end
            if d.hot then props = props + PHOT end
            if d.radio then props = props + PRADIO end
            if NEUT_PASS[d.id] and PNEUT ~= 0 then props = props + PNEUT end
            def.Properties = props
            def.HighTemperatureTransition = -1
            def.LowTemperatureTransition = -1
            if d.hi then
                local target = resultId(d.hi[2])
                if target then def.HighTemperature = d.hi[1]; def.HighTemperatureTransition = target end
            end
            if d.lo then
                local target = resultId(d.lo[2])
                if target then def.LowTemperature = d.lo[1]; def.LowTemperatureTransition = target end
            end
            local ct = d.temp
            def.Create = function(i, x, y, tt, v)
                if ct then PP(i, "temp", ct) end
                local f = INIT[tt]
                if f then f(i) end
            end
            EL.element(t, def)
        end
    end
end
defineAll()

-- ============================================================
-- 7. ENGINE HELPERS
-- ============================================================
local function addPressure(x, y, v)
    local cx, cy = floor(x / 4), floor(y / 4)
    local ok, cur = pcall(sim.pressure, cx, cy)
    if ok and cur then
        pcall(sim.pressure, cx, cy, 1, 1, max(-256, min(256, cur + v)))
    end
end

local function addTemp(p, d)
    local t = PP(p, "temp") + d
    if t < 1 then t = 1 elseif t > 9000 then t = 9000 end
    PP(p, "temp", t)
end

local function setType(p, t)
    sim.partChangeType(p, t)
    local m = SPAWNMIN[t]
    if m and PP(p, "temp") < m then PP(p, "temp", m) end
    local f = INIT[t]
    if f then f(p) end
end

-- Rising gases: upward push + sideways drift (applied every frame).
local RISE, DRIFT = {}, {}
for id, v in pairs(RISE_SRC) do if T[id] then RISE[T[id]] = v end end
for id, v in pairs(DRIFT_SRC) do if T[id] then DRIFT[T[id]] = v end end

local function lift(i, t)
    local rv = RISE[t]
    if not rv then return end
    local vy = PP(i, "vy")
    if vy > -2.5 then PP(i, "vy", vy - rv) end
    local dr = DRIFT[t]
    if dr then
        local vx = PP(i, "vx") + (random() - 0.5) * dr
        if vx > 1.2 then vx = 1.2 elseif vx < -1.2 then vx = -1.2 end
        PP(i, "vx", vx)
    end
end

-- Neighbour scan (reused tables)
local nbGen, nbId, nbCnt = {}, {}, {}
local gen = 0
local ex, ey, nE = {}, {}, 0

local function scan(x, y)
    gen = gen + 1
    nE = 0
    for dy = -1, 1 do
        local ny = y + dy
        if ny >= 0 and ny < YRES then
            for dx = -1, 1 do
                if dx ~= 0 or dy ~= 0 then
                    local nx = x + dx
                    if nx >= 0 and nx < XRES then
                        local p = PID(nx, ny)
                        if p then
                            local t = PP(p, "type")
                            if t then
                                if nbGen[t] == gen then
                                    nbCnt[t] = nbCnt[t] + 1
                                else
                                    nbGen[t] = gen; nbId[t] = p; nbCnt[t] = 1
                                end
                            end
                        else
                            nE = nE + 1; ex[nE] = nx; ey[nE] = ny
                        end
                    end
                end
            end
        end
    end
end

local function seen(t)
    if nbGen[t] == gen then return nbId[t] end
    return nil
end

local function seenAny(ids)
    for k = 1, #ids do
        local p = seen(ids[k])
        if p then return p end
    end
    return nil
end

local function takeEmpty(y, up)
    if nE == 0 then return nil end
    local k
    if up then
        for _ = 1, 6 do
            local j = random(1, nE)
            if ey[j] < y then k = j; break end
        end
    end
    k = k or random(1, nE)
    local px, py = ex[k], ey[k]
    ex[k] = ex[nE]; ey[k] = ey[nE]; nE = nE - 1
    return px, py
end

local function spawn(t, x, y, temp, up)
    local px, py = takeEmpty(y, up)
    if not px then return nil end
    local p = sim.partCreate(-1, px, py, t)
    if p and p >= 0 then
        if temp then
            local m = SPAWNMIN[t]
            if m and temp < m then temp = m end
            PP(p, "temp", temp)
        end
        return p
    end
    return nil
end

local FLAMES = {}
for _, id in ipairs({T.FIRE, BI.FIRE, BI.PLSM, T.LAVA, BI.LAVA}) do FLAMES[#FLAMES + 1] = id end
local function flameNear()
    for k = 1, #FLAMES do
        if nbGen[FLAMES[k]] == gen then return true end
    end
    return false
end

-- ============================================================
-- 8. COMPILE RULES
-- ============================================================
local function idList(names)
    if not names then return nil end
    local out = {}
    for _, n in ipairs(listOf(names)) do
        for _, id in ipairs(typeIds(n)) do out[#out + 1] = id end
    end
    return out
end

local CR = {}
for src, list in pairs(RULES) do
    local st = T[src]
    if st then
        local compiled = {}
        for _, r in ipairs(list) do
            local c = {
                p = min(100, (r.p or 100) * GATE),
                tmin = r.tmin, tmax = r.tmax, fl = r.fl, dS = r.dS or r.dT, dO = r.dO or r.dT,
                pr = r.pr, gu = r.gu, one = r.one, oT = r.oT, sT = r.sT,
            }
            local valid = true
            if r.w then
                c.w = idList(r.w)
                if #c.w == 0 then valid = false end
            end
            if r.n then c.n = idList(r.n) end
            if r.nx then c.nx = idList(r.nx) end
            if r.s then c.s = resultId(r.s); if c.s == nil then valid = false end end
            if r.o then c.o = resultId(r.o); if c.o == nil then valid = false end end
            if r.g then
                c.g = {}
                for _, n in ipairs(r.g) do
                    local id = resultId(n)
                    if id then c.g[#c.g + 1] = id end
                end
                if #c.g == 0 then c.g = nil end
            end
            if valid then compiled[#compiled + 1] = c end
        end
        if #compiled > 0 then CR[st] = compiled end
    end
end

local CB = {}
for id, b in pairs(BURN) do
    local t = T[id]
    if t then
        local outs = {}
        for _, o in ipairs(listOf(b.out)) do outs[#outs + 1] = T[o] or 0 end
        CB[t] = {
            ign = b.ign, flame = min(100, (b.flame or 0) * GATE), rate = min(100, (b.rate or 20) * GATE),
            left = b.left and T[b.left], alt = b.alt and T[b.alt], altp = b.altp or 0,
            outs = outs, ft = b.ft or 1100, expl = b.expl, life = b.life,
        }
    end
end

-- ============================================================
-- 9. REACTION ENGINE
-- ============================================================
local function apply(r, i, x, y, other)
    if r.dS then addTemp(i, r.dS) end
    if other and r.dO then addTemp(other, r.dO) end
    if r.pr then addPressure(x, y, r.pr) end
    if other then
        if r.o == "x" then
            sim.partKill(other)
        elseif r.o then
            setType(other, r.o)
            if r.oT then PP(other, "temp", r.oT) end
        end
    end
    if r.g then
        local gt = PP(i, "temp")
        if r.one then
            spawn(r.g[random(1, #r.g)], x, y, gt, r.gu)
        else
            for k = 1, #r.g do spawn(r.g[k], x, y, gt, r.gu) end
        end
    end
    if r.s == "x" then
        sim.partKill(i)
    elseif r.s then
        setType(i, r.s)
        if r.sT then PP(i, "temp", r.sT) end
    end
end

local function react(i, x, y, t)
    local rl = CR[t]
    if not rl then return false end
    scan(x, y)
    local temp = PP(i, "temp")
    for k = 1, #rl do
        local r = rl[k]
        local ok = true
        if r.tmin and temp < r.tmin then
            ok = false
            if r.fl and (not r.tmax or temp <= r.tmax) and flameNear() then ok = true end
        end
        if ok and r.tmax and temp > r.tmax then ok = false end
        if ok and r.nx and seenAny(r.nx) then ok = false end
        if ok and r.n and not seenAny(r.n) then ok = false end
        local other
        if ok and r.w then
            other = seenAny(r.w)
            if not other then ok = false end
        end
        if ok and random() * 100 < r.p then
            apply(r, i, x, y, other)
            return true
        end
    end
    return false
end

local function initFire(p, outType, ft, life)
    PP(p, "life", life or random(30, 70))
    PP(p, "ctype", outType or 0)
    PP(p, "temp", ft or 1100)
end

local OXYG = T.OXYG
local CO2T, NITRT = T.CO2, T.NITR

local function burn(i, x, y, t)
    local b = CB[t]
    if not b then return false end
    local temp = PP(i, "temp")
    if temp >= b.ign then
        if random() * 100 >= b.rate then return false end
        scan(x, y)
    else
        if not b.flame or b.flame <= 0 then return false end
        if random(GATE) ~= 1 then return false end
        scan(x, y)
        if not flameNear() or random() * 100 >= b.flame then return false end
    end
    local o2 = OXYG and seen(OXYG)
    if nE == 0 and not o2 then return false end
    if b.left and nE == 0 then return false end
    if (CO2T and seen(CO2T)) or (NITRT and seen(NITRT)) then
        if random() < 0.6 then return false end
    end
    local outT = b.outs[random(1, #b.outs)] or 0
    local ft = b.ft
    if o2 then
        sim.partKill(o2)
        ft = ft + 200
        if b.expl then addPressure(x, y, b.expl) end
    end
    local life = b.life or random(30, 70)
    if b.left then
        local lt = b.left
        if b.alt and random() * 100 < b.altp then lt = b.alt end
        local f = spawn(T.FIRE, x, y, ft, true)
        if f then initFire(f, outT, ft, life) end
        setType(i, lt)
    else
        setType(i, T.FIRE)
        initFire(i, outT, ft, life)
    end
    return true
end

local function makeUpdate(t)
    local hasBurn = CB[t] ~= nil
    local rises = RISE[t] ~= nil
    return function(i, x, y)
        if rises then lift(i, t) end
        if random(GATE) ~= 1 then
            if hasBurn then burn(i, x, y, t) end
            return
        end
        if hasBurn and burn(i, x, y, t) then return end
        react(i, x, y, t)
    end
end

-- ============================================================
-- 10. FIRE
-- ============================================================
INIT[T.FIRE] = function(p)
    PP(p, "life", random(25, 60))
    PP(p, "ctype", 0)
    PP(p, "temp", 1100)
end

local function updateFire(i, x, y)
    local life = PP(i, "life") - 1
    if life <= 0 then
        local c = PP(i, "ctype")
        if c and c > 0 and c ~= T.FIRE then
            PP(i, "life", 0)
            setType(i, c)
        else
            sim.partKill(i)
        end
        return
    end
    PP(i, "life", life)
    lift(i, T.FIRE)
    local ft = PP(i, "temp")
    for dy = -1, 1 do
        local ny = y + dy
        if ny >= 0 and ny < YRES then
            for dx = -1, 1 do
                if dx ~= 0 or dy ~= 0 then
                    local nx = x + dx
                    if nx >= 0 and nx < XRES then
                        local p = PID(nx, ny)
                        if p and PP(p, "type") ~= T.FIRE then
                            local nt = PP(p, "temp")
                            if nt < ft then PP(p, "temp", nt + (ft - nt) * 0.06) end
                        end
                    end
                end
            end
        end
    end
    PP(i, "temp", max(500, ft - 4))
    react(i, x, y, T.FIRE)
end

-- ============================================================
-- 11. ANIMALS
-- ============================================================
local ANIM = {}
for id, a in pairs(ANIM_SRC) do
    local t = T[id]
    if t then
        local foodSet, foodIds = {}, {}
        for _, f in ipairs(a.food) do
            for _, ft in ipairs(typeIds(f)) do foodSet[ft] = true; foodIds[#foodIds + 1] = ft end
        end
        ANIM[t] = {food = foodIds, foodSet = foodSet, prod = T[a.prod], prodp = a.prodp}
    end
end
local HAZ = {}
for _, h in ipairs(HAZARDS) do
    for _, ht in ipairs(typeIds(h[1])) do
        HAZ[#HAZ + 1] = {t = ht, p = h[2], to = T[h[3]]}
    end
end

local function initAnimal(p)
    PP(p, "life", 1500)
    PP(p, "tmp", random(1, 2))
    PP(p, "tmp2", random(5, 15))
end
for t in pairs(ANIM) do INIT[t] = initAnimal end

local setPos = sim.partPosition or function(i, nx, ny) PP(i, "x", nx); PP(i, "y", ny) end

local function findFood(x, y, foodSet)
    for dx = -6, 6 do
        local nx = x + dx
        if nx >= 0 and nx < XRES then
            for dy = -1, 1 do
                local ny = y + dy
                if ny >= 0 and ny < YRES then
                    local p = PID(nx, ny)
                    if p and foodSet[PP(p, "type")] then return nx end
                end
            end
        end
    end
    return nil
end

local function updateAnimal(i, x, y, t)
    local a = ANIM[t]
    local temp = PP(i, "temp")
    if temp > 700 then setType(i, T.ASH); return end
    scan(x, y)
    for k = 1, #HAZ do
        local h = HAZ[k]
        if nbGen[h.t] == gen and random() * 100 < h.p then
            if h.to then setType(i, h.to) else sim.partKill(i) end
            return
        end
    end
    if (temp > 335 or temp < 260) and random() < 0.015 then setType(i, T.CHKP); return end
    local e = PP(i, "life")
    if e <= 0 then initAnimal(i); e = 1500 end
    if random() < 0.05 then e = e - 1; PP(i, "life", e) end
    if e <= 1 then setType(i, T.RDGS); return end
    if e < 1400 then
        for k = 1, #a.food do
            local f = seen(a.food[k])
            if f then
                sim.partKill(f)
                e = min(1800, e + 450)
                PP(i, "life", e)
                if a.prod and random() * 100 < a.prodp then spawn(a.prod, x, y, nil, false) end
                if random() < 0.2 then spawn(T.FERT, x, y, nil, false) end
                break
            end
        end
    end
    if e > 900 and a.prod and random() < 0.0004 then spawn(a.prod, x, y, nil, false) end
    local tm = PP(i, "tmp2") - 1
    if tm > 0 then PP(i, "tmp2", tm); return end
    PP(i, "tmp2", random(8, 16))
    if y + 1 < YRES and not PID(x, y + 1) then return end
    local dir = PP(i, "tmp")
    if (dir ~= 1 and dir ~= 2) or random() < 0.15 then dir = random(1, 2); PP(i, "tmp", dir) end
    if e < 1000 and random() < 0.7 then
        local fx = findFood(x, y, a.foodSet)
        if fx and fx ~= x then dir = (fx > x) and 1 or 2; PP(i, "tmp", dir) end
    end
    local nx = x + ((dir == 1) and 1 or -1)
    if nx < 1 or nx >= XRES - 1 then PP(i, "tmp", (dir == 1) and 2 or 1); return end
    if not PID(nx, y) then
        setPos(i, nx, y)
    elseif y > 1 and not PID(nx, y - 1) and not PID(x, y - 1) then
        setPos(i, nx, y - 1)
    else
        PP(i, "tmp", (dir == 1) and 2 or 1)
    end
end

-- ============================================================
-- 12. RADIOACTIVE ELEMENTS AND LEAD SHIELD
-- ============================================================
local FISS = {}
if T.URAN then FISS[T.URAN] = {spont=0.005, cap=4, yield=2, heat=40, pr=0.2, mod=true} end
if T.PLUT then FISS[T.PLUT] = {spont=0.01, cap=10, yield=3, heat=90, pr=0.4, mod=false} end

local function emitNeutron(x, y)
    if not BI.NEUT then return end
    local nx, ny = x + random(-1, 1), y + random(-1, 1)
    if nx < 0 or ny < 0 or nx >= XRES or ny >= YRES or PID(nx, ny) then return end
    local n = sim.partCreate(-1, nx, ny, BI.NEUT)
    if n and n >= 0 then
        local a = random() * 6.2832
        PP(n, "vx", math.cos(a) * 3)
        PP(n, "vy", math.sin(a) * 3)
    end
end

local function updateFissile(i, x, y, t)
    local f = FISS[t]
    if random() * 100 < f.spont then emitNeutron(x, y) end
    if not BI.NEUT then return end
    for dx = -2, 2 do
        local nx = x + dx
        if nx >= 0 and nx < XRES then
            for dy = -2, 2 do
                local ny = y + dy
                if ny >= 0 and ny < YRES then
                    local p = PID(nx, ny)
                    if p and PP(p, "type") == BI.NEUT then
                        local cap = f.cap
                        if f.mod then
                            scan(x, y)
                            if (T.WATR and seen(T.WATR)) or (T.ICEW and seen(T.ICEW)) or (T.CARB and seen(T.CARB)) then cap = cap * 3 end
                        end
                        if random() * 100 < cap then
                            sim.partKill(p)
                            for _ = 1, f.yield do emitNeutron(x, y) end
                            addTemp(i, f.heat)
                            addPressure(x, y, f.pr)
                            return
                        end
                    end
                end
            end
        end
    end
end

local function updateLead(i, x, y)
    if not BI.NEUT then return end
    for dx = -1, 1 do
        for dy = -1, 1 do
            local nx, ny = x + dx, y + dy
            if nx >= 0 and nx < XRES and ny >= 0 and ny < YRES then
                local p = PID(nx, ny)
                if p and PP(p, "type") == BI.NEUT and random() < 0.4 then sim.partKill(p) end
            end
        end
    end
end

-- ============================================================
-- 13. SQUEEZER
-- ============================================================
local SQ = {}
for id, q in pairs(SQZ) do
    local t = T[id]
    if t and T[q.out] then
        local gl = {}
        if q.g then for _, n in ipairs(q.g) do if T[n] then gl[#gl + 1] = T[n] end end end
        SQ[t] = {out = T[q.out], g = gl, p = q.p, t = q.t}
    end
end

local function squeezeParticle(p)
    local r = SQ[PP(p, "type")]
    if not r or random() * 100 >= r.p then return false end
    local x, y = floor(PP(p, "x") + 0.5), floor(PP(p, "y") + 0.5)
    scan(x, y)
    for k = 1, #r.g do spawn(r.g[k], x, y, PP(p, "temp"), false) end
    setType(p, r.out)
    if r.t then PP(p, "temp", r.t) end
    return true
end

local function squeezeArea(cx, cy, rx, ry)
    for x = cx - rx, cx + rx do
        for y = cy - ry, cy + ry do
            if x >= 0 and x < XRES and y >= 0 and y < YRES then
                local p = PID(x, y)
                if p then squeezeParticle(p) end
            end
        end
    end
end

local function updateSqueezerBlock(i, x, y)
    for dx = -1, 1 do
        for dy = -1, 1 do
            if dx ~= 0 or dy ~= 0 then
                local nx, ny = x + dx, y + dy
                if nx >= 0 and nx < XRES and ny >= 0 and ny < YRES then
                    local p = PID(nx, ny)
                    if p then squeezeParticle(p) end
                end
            end
        end
    end
end

local SQZE_IDENT = GROUP .. "_PT_SQZE"
local sqzDown, sqzX, sqzY = false, 0, 0

local function sqzSelected(button)
    local ok, sel = pcall(function()
        if button == 3 then return tpt.selectedr end
        if button == 2 then return tpt.selecteda end
        return tpt.selectedl
    end)
    return ok and sel == SQZE_IDENT
end

local function sqzBrush(x, y)
    local ok, bx, by = pcall(function() return tpt.brushx, tpt.brushy end)
    local rx = (ok and type(bx) == "number") and bx or 3
    local ry = (ok and type(by) == "number") and by or 3
    squeezeArea(x, y, rx, ry)
end

if event then
    event.register(event.mousedown, function(x, y, button)
        if x >= 0 and y >= 0 and x < XRES and y < YRES and sqzSelected(button) then
            sqzDown, sqzX, sqzY = true, x, y
            sqzBrush(x, y)
            return false
        end
    end)
    event.register(event.mouseup, function() sqzDown = false end)
    event.register(event.mousemove, function(x, y)
        if sqzDown then
            sqzX, sqzY = x, y
            return false
        end
    end)
    event.register(event.tick, function()
        if sqzDown then sqzBrush(sqzX, sqzY) end
    end)
end

-- ============================================================
-- 13B. MOVING SOLID (MVSL)   (added in v12.5)
-- tmp = 1 : shape drawn while PAUSED -> bonded, touching MVSL share velocity
-- tmp = 0 : drawn while running      -> loose block
-- ctype   : material, set with the property tool (colour + strength)
-- ============================================================
local MV = (function()
    local M = {}
    local GRAY = 0x8C8C8C
    local NB = {{-1,0},{1,0},{0,-1},{0,1},{-1,-1},{1,-1},{-1,1},{1,1}}
    local myT = T.MVSL
    if not myT then return M end

    local function paused()
        local ok, p = pcall(tpt.set_pause)
        if ok and p ~= nil then return p == 1 or p == true end
        return true     -- unknown: assume paused so shapes stay bonded
    end

    INIT[myT] = function(i)
        PP(i, "tmp", paused() and 1 or 0)
    end

    -- material strength (how hard it hits) and target toughness (how hard it is to break)
    local POWER_SRC = {IRON=3, STEL=3.5, TITA=5, GOLD=2, LEAD=2, STON=2, ROCK=2, BRIK=2,
                       GLAS=1, WOOD=1.2, ICE=1, ["!DMND"]=8, ["!COPR"]=2.5}
    local TOUGH_SRC = {GLAS=1.5, ICE=1.5, PLNT=1, LEAF=0.8, WOOD=2.5, CARB=3, STON=4, ROCK=4,
                       BRIK=4, LEAD=6, GOLD=8, IRON=12, STEL=14, TITA=20, ["!COPR"]=8,
                       ["!DMND"]=999}
    local DEBRIS_SRC = {GLAS="!BGLA", ICE="!SNOW", STON="GRVL", ROCK="GRVL", BRIK="GRVL"}
    local DEF_POWER, DEF_TOUGH = 1.5, 3

    local POWER, TOUGH, DEBRIS = {}, {}, {}
    for name, v in pairs(POWER_SRC) do for _, t in ipairs(typeIds(name)) do POWER[t] = v end end
    for name, v in pairs(TOUGH_SRC) do for _, t in ipairs(typeIds(name)) do TOUGH[t] = v end end
    for name, r in pairs(DEBRIS_SRC) do
        local rt = resultId(r)
        if rt then for _, t in ipairs(typeIds(name)) do DEBRIS[t] = rt end end
    end

    local isSolidCache = {}
    local function isSolid(t)
        local c = isSolidCache[t]
        if c == nil then
            local ok, props = pcall(EL.property, t, "Properties")
            c = ok and type(props) == "number" and bit.band(props, TS) ~= 0
            isSolidCache[t] = c
        end
        return c
    end

    local function sgn(v)
        if v > 0.5 then return 1 elseif v < -0.5 then return -1 end
        return 0
    end

    local function impact(i, x, y, vx, vy, s2)
        local dx, dy = sgn(vx), sgn(vy)
        if dx == 0 and dy == 0 then return end
        local nx, ny = x + dx, y + dy
        if nx < 0 or ny < 0 or nx >= XRES or ny >= YRES then return end
        local o = PID(nx, ny)
        if not o then return end
        local ot = PP(o, "type")
        if not ot or ot == myT or not isSolid(ot) then return end
        local ct = PP(i, "ctype")
        local power = (ct and ct > 0) and (POWER[ct] or DEF_POWER) or 1
        if math.sqrt(s2) * power >= (TOUGH[ot] or DEF_TOUGH) then
            local d = DEBRIS[ot]
            if d then setType(o, d) else sim.partKill(o) end
            PP(i, "vx", vx * 0.6)
            PP(i, "vy", vy * 0.6)
        end
    end

    function M.update(i, x, y)
        local vx, vy = PP(i, "vx"), PP(i, "vy")
        local s2 = vx * vx + vy * vy
        if s2 >= 1 then impact(i, x, y, vx, vy, s2) end
        -- bonded shapes: share velocity with 2 random touching MVSL (moving: every frame; resting: rarely)
        if (s2 > 0.01 or random(4) == 1) and PP(i, "tmp") == 1 then
            for _ = 1, 2 do
                local n = NB[random(8)]
                local nx, ny = x + n[1], y + n[2]
                if nx >= 0 and ny >= 0 and nx < XRES and ny < YRES then
                    local p = PID(nx, ny)
                    if p and PP(p, "type") == myT and PP(p, "tmp") == 1 then
                        vx, vy = PP(i, "vx"), PP(i, "vy")
                        local ax, ay = (vx + PP(p, "vx")) * 0.5, (vy + PP(p, "vy")) * 0.5
                        PP(i, "vx", ax); PP(i, "vy", ay)
                        PP(p, "vx", ax); PP(p, "vy", ay)
                    end
                end
            end
        end
    end

    local colCache = {}
    local PMF = (ren and ren.PMODE_FLAT) or 1
    function M.graphics(i)
        local ct = PP(i, "ctype") or 0
        local c = colCache[ct]
        if not c then
            local col = GRAY
            if ct > 0 then
                local ok, v = pcall(EL.property, ct, "Colour")
                if ok and type(v) == "number" then col = v end
            end
            c = {floor(col / 65536) % 256, floor(col / 256) % 256, col % 256}
            colCache[ct] = c
        end
        return 0, PMF, 255, c[1], c[2], c[3], 0, 0, 0, 0
    end

    return M
end)()

-- ============================================================
-- 13C. COOLANT / SIGN ERASER / CLOUD / STAINED WATER  (added in v12.5)
-- CLNT : heat sink. Its own temp is only changed by the property tool (HeatConduct 0).
-- SIBE : deletes any sign whose box (or pointer) it touches.
-- CLUD : gas. ctype = weather (powder or liquid). tmp = absorbed vapour, tmp2 = 1 when rain came from vapour.
-- SNWT : tmp = packed RGB stain colour (0 = original blue).
-- ============================================================
local V = (function()
    local M = {}
    local NB = {{-1,0},{1,0},{0,-1},{0,1},{-1,-1},{1,-1},{-1,1},{1,1}}
    local PMF = (ren and ren.PMODE_FLAT) or 1
    local abs = math.abs

    local rgbCache = {}
    local function elemRGB(t)
        local c = rgbCache[t]
        if not c then
            local ok, v = pcall(EL.property, t, "Colour")
            if not (ok and type(v) == "number") then v = 0x888888 end
            c = {floor(v / 65536) % 256, floor(v / 256) % 256, v % 256}
            rgbCache[t] = c
        end
        return c
    end

    -- ---------------- CLNT : coolant ----------------
    local myC = T.CLNT
    local hcCache = {}
    local function conducts(t)
        local c = hcCache[t]
        if c == nil then
            local ok, v = pcall(EL.property, t, "HeatConduct")
            c = (ok and type(v) == "number" and v > 0) and true or false
            hcCache[t] = c
        end
        return c
    end

    if myC then
        function M.coolant(i, x, y)
            if random(2) ~= 1 then return end
            local tc = PP(i, "temp")
            for k = 1, 8 do
                local n = NB[k]
                local nx, ny = x + n[1], y + n[2]
                if nx >= 0 and ny >= 0 and nx < XRES and ny < YRES then
                    local o = PID(nx, ny)
                    if o then
                        local ot = PP(o, "type")
                        if ot and ot ~= myC and conducts(ot) then
                            local to = PP(o, "temp")
                            local d = tc - to
                            if d > 0.5 or d < -0.5 then PP(o, "temp", to + d * 0.2) end
                        end
                    end
                end
            end
        end

        local COLD, NORM, HOT = 173.15, 293.15, 973.15
        function M.coolantGfx(i)
            local t = PP(i, "temp")
            local r, g, b
            if t <= COLD then
                r, g, b = 255, 232, 122
            elseif t < NORM then
                local f = (t - COLD) / (NORM - COLD)
                r, g, b = 255 + (212 - 255) * f, 232 + (175 - 232) * f, 122 + (55 - 122) * f
            elseif t < HOT then
                local f = (t - NORM) / (HOT - NORM)
                r, g, b = 212 + (110 - 212) * f, 175 + (80 - 175) * f, 55 + (0 - 55) * f
            else
                r, g, b = 110, 80, 0
            end
            return 0, PMF, 255, floor(r), floor(g), floor(b), 0, 0, 0, 0
        end
    end

    -- ---------------- SIBE : sign box eraser ----------------
    local mySE = T.SIBE
    if mySE then
        local signs, dirty, tickN, lastBuild = {}, true, 0, 0
        local function fld(s, k)
            local ok, v = pcall(function() return s[k] end)
            if ok then return v end
        end
        local function rebuild()
            signs = {}
            local S = sim.signs
            for n = 1, 16 do
                local okS, s = pcall(function() return S[n] end)
                if okS and s then
                    local text = fld(s, "text")
                    if text then
                        local sx, sy = fld(s, "x") or 0, fld(s, "y") or 0
                        local left, top = fld(s, "screenX"), fld(s, "screenY")
                        local w, h = fld(s, "width"), fld(s, "height")
                        if not (left and top and w and h) then
                            -- fallback: generous box around the pointer (width from text length)
                            w = (#text * 6 + 8) * 2
                            h = 26
                            left, top = sx - (#text * 6 + 8), sy - 20
                        end
                        signs[#signs + 1] = {id = fld(s, "id") or n, x = sx, y = sy,
                                             l = left, t = top, r = left + w, b = top + h}
                    end
                end
            end
            dirty = false
            lastBuild = tickN
        end
        event.register(event.tick, function() tickN = tickN + 1 end)

        function M.eraser(i, x, y)
            if dirty or tickN - lastBuild >= 5 then rebuild() end
            for k = 1, #signs do
                local s = signs[k]
                if (x >= s.l - 1 and x <= s.r + 1 and y >= s.t - 1 and y <= s.b + 1)
                   or (abs(x - s.x) <= 1 and abs(y - s.y) <= 1) then
                    pcall(sim.signs.delete, s.id)
                    dirty = true
                    return
                end
            end
        end
    end

    -- ---------------- CLUD : cloud ----------------
    local myCl = T.CLUD
    if myCl then
        local MAXC = 20
        local WATRID = resultId("WATR")
        local VAP = {}
        for _, t in ipairs(typeIds("VAPR")) do VAP[t] = true end

        local weatherCache = {}
        local function weatherOK(t)
            local c = weatherCache[t]
            if c == nil then
                c = false
                if t ~= myCl and not (ANIM and ANIM[t]) then
                    local ok, props = pcall(EL.property, t, "Properties")
                    if ok and type(props) == "number" then
                        local liq = bit.band(props, TL) ~= 0
                        local pow = bit.band(props, TP) ~= 0
                        local sol = bit.band(props, TS) ~= 0
                        local gas = bit.band(props, TG) ~= 0
                        c = (liq or pow) and not sol and not gas
                    end
                end
                weatherCache[t] = c
            end
            return c
        end

        function M.cloud(i, x, y)
            local ct, tmp = PP(i, "ctype"), PP(i, "tmp")
            local auto = PP(i, "tmp2") == 1
            if ct ~= 0 and not weatherOK(ct) then
                ct = 0; PP(i, "ctype", 0); PP(i, "tmp2", 0); auto = false
            end
            if auto and ct ~= WATRID then PP(i, "tmp2", 0); auto = false end   -- property tool took over

            -- absorb water vapour (plain clouds and vapour-made rain only)
            if (ct == 0 or auto) and tmp < MAXC and random(3) == 1 then
                local n = NB[random(8)]
                local nx, ny = x + n[1], y + n[2]
                if nx >= 0 and ny >= 0 and nx < XRES and ny < YRES then
                    local o = PID(nx, ny)
                    if o and VAP[PP(o, "type")] then
                        sim.partKill(o)
                        tmp = tmp + 1
                        PP(i, "tmp", tmp)
                        if ct == 0 and WATRID then
                            ct = WATRID
                            PP(i, "ctype", ct); PP(i, "tmp2", 1)
                            auto = true
                        end
                    end
                end
            end

            -- make weather just below the cloud
            if ct ~= 0 and (not auto or tmp > 0) and random(4) == 1 then
                local nx, ny = x + random(-1, 1), y + 1
                if nx >= 0 and ny >= 0 and nx < XRES and ny < YRES then
                    local p = sim.partCreate(-1, nx, ny, ct)
                    if p and p >= 0 and auto then
                        tmp = tmp - 1
                        PP(i, "tmp", tmp)
                        if tmp <= 0 then PP(i, "ctype", 0); PP(i, "tmp2", 0) end
                    end
                end
            end
        end

        function M.cloudGfx(i)
            local f = min((PP(i, "tmp") or 0) / MAXC, 1)
            local r, g, b = 255 - 105 * f, 255 - 100 * f, 255 - 90 * f
            local ct = PP(i, "ctype")
            if ct and ct > 0 then
                local c = elemRGB(ct)
                r, g, b = r * 0.6 + c[1] * 0.4, g * 0.6 + c[2] * 0.4, b * 0.6 + c[3] * 0.4
            end
            return 0, PMF, 220, floor(r), floor(g), floor(b), 0, 0, 0, 0
        end
    end

    -- ---------------- SNWT : stained water ----------------
    local myS = T.SNWT
    if myS then
        local BASE = {47, 107, 255}
        local function unpack3(v)
            if v == 0 then return BASE[1], BASE[2], BASE[3] end
            return floor(v / 65536) % 256, floor(v / 256) % 256, v % 256
        end
        local function pack3(r, g, b)
            local v = floor(r) * 65536 + floor(g) * 256 + floor(b)
            if v == 0 then v = 1 end
            return v
        end
        local function mixPacked(a, ar, ag, ab, f)     -- a = packed colour, (ar,ag,ab) = other colour
            local r, g, b = unpack3(a)
            return pack3(r + (ar - r) * f, g + (ag - g) * f, b + (ab - b) * f)
        end

        -- what can stain: p = chance per try, k = how strongly it tints, eat = used up when it stains
        local STAIN_SRC = {
            SOIL={p=0.5,k=0.35,eat=true}, FRSL={p=0.5,k=0.40,eat=true}, CLAY={p=0.5,k=0.40,eat=true},
            RUST={p=0.6,k=0.50,eat=true}, IROX={p=0.6,k=0.50,eat=true}, PATI={p=0.6,k=0.50,eat=true},
            SULF={p=0.6,k=0.50,eat=true}, RDGS={p=0.4,k=0.40,eat=true}, FERT={p=0.4,k=0.30,eat=true},
            CROT={p=0.5,k=0.50,eat=true}, ORNG={p=0.5,k=0.50,eat=true}, APPL={p=0.5,k=0.50,eat=true},
            BANA={p=0.5,k=0.50,eat=true}, MUD ={p=0.5,k=0.40,eat=true},
            LEAF={p=0.06,k=0.12}, PLNT={p=0.04,k=0.10}, MOSS={p=0.05,k=0.12}, VINE={p=0.04,k=0.10},
            WOOD={p=0.03,k=0.10}, BRIK={p=0.03,k=0.10}, COPR={p=0.04,k=0.10},
        }
        local STAIN = {}
        for name, v in pairs(STAIN_SRC) do for _, t in ipairs(typeIds(name)) do STAIN[t] = v end end

        function M.stained(i, x, y)
            if random(2) ~= 1 then return end
            local n = NB[random(8)]
            local nx, ny = x + n[1], y + n[2]
            if nx < 0 or ny < 0 or nx >= XRES or ny >= YRES then return end
            local o = PID(nx, ny)
            if not o then return end
            local ot = PP(o, "type")
            if ot == myS then
                local a, b = PP(i, "tmp"), PP(o, "tmp")
                if a ~= b then
                    local br, bg, bb = unpack3(b)
                    local m = mixPacked(a, br, bg, bb, 0.5)
                    PP(i, "tmp", m); PP(o, "tmp", m)
                end
            else
                local st = STAIN[ot]
                if st and random() < st.p then
                    local c = elemRGB(ot)
                    PP(i, "tmp", mixPacked(PP(i, "tmp"), c[1], c[2], c[3], st.k))
                    if st.eat then sim.partKill(o) end
                end
            end
        end

        function M.stainedGfx(i)
            local r, g, b = unpack3(PP(i, "tmp") or 0)
            return 0, PMF, 255, r, g, b, 0, 0, 0, 0
        end
    end

    return M
end)()

-- ============================================================
-- 14. ATTACH UPDATE FUNCTIONS
-- ============================================================
local special = {}

if T.FIRE then
    special[T.FIRE] = updateFire
end

for t in pairs(ANIM) do
    local animalType = t
    special[animalType] = function(i, x, y)
        updateAnimal(i, x, y, animalType)
    end
end

if T.SQZE then
    special[T.SQZE] = updateSqueezerBlock
end

if T.MVSL and MV.update then
    special[T.MVSL] = MV.update
end

if T.CLNT and V.coolant then special[T.CLNT] = V.coolant end
if T.SIBE and V.eraser  then special[T.SIBE] = V.eraser end
if T.CLUD and V.cloud   then special[T.CLUD] = V.cloud end
if T.SNWT and V.stained then special[T.SNWT] = V.stained end

if T.LEAD then
    special[T.LEAD] = updateLead
end

for t in pairs(FISS) do
    local fissileType = t
    local generic = makeUpdate(fissileType)

    special[fissileType] = function(i, x, y)
        updateFissile(i, x, y, fissileType)
        generic(i, x, y)
    end
end

local attached = {}
for t, fn in pairs(special) do
    EL.property(t, "Update", fn)
    attached[t] = true
end
for t in pairs(CR) do
    if not attached[t] then EL.property(t, "Update", makeUpdate(t)); attached[t] = true end
end
for t in pairs(CB) do
    if not attached[t] then EL.property(t, "Update", makeUpdate(t)); attached[t] = true end
end
-- rising gases that have no rules of their own still need the lift function
for t in pairs(RISE) do
    if not attached[t] then EL.property(t, "Update", makeUpdate(t)); attached[t] = true end
end

-- v12.5: Moving solid takes its colour from its ctype material
if T.MVSL and MV.graphics then
    EL.property(T.MVSL, "Graphics", MV.graphics)
end
-- v12.5: coolant, cloud and stained water colours
if T.CLNT and V.coolantGfx then EL.property(T.CLNT, "Graphics", V.coolantGfx) end
if T.CLUD and V.cloudGfx   then EL.property(T.CLUD, "Graphics", V.cloudGfx) end
if T.SNWT and V.stainedGfx then EL.property(T.SNWT, "Graphics", V.stainedGfx) end

-- v12.6: rocky texture. Coarse grain blotches + fine speckle + dark pits + light mineral flecks,
-- fixed per pixel position so the rock does not flicker.
if T.ROCK then
    local PMFR = (ren and ren.PMODE_FLAT) or 1
    local function rockGfx(i)
        local x, y = floor(PP(i, "x") + 0.5), floor(PP(i, "y") + 0.5)
        local h  = (x * 73856093 + y * 19349663) % 1000            -- fine noise
        local gx, gy = floor(x / 3), floor(y / 3)
        local h2 = (gx * 83492791 + gy * 2654435761) % 1000         -- 3x3 grain blotches
        local v = 80 + (h2 / 1000) * 80 + (h / 1000 - 0.5) * 55
        if h % 17 == 0 then v = v - 60 end                          -- dark pits / cracks
        if h % 23 == 1 then v = v + 50 end                          -- light mineral flecks
        local warm = (h2 % 21) - 10                                  -- slight brown / grey tint
        local r = max(0, min(255, floor(v + warm * 0.6)))
        local g = max(0, min(255, floor(v)))
        local b = max(0, min(255, floor(v - warm * 0.6 - 6)))
        return 0, PMFR, 255, r, g, b, 0, 0, 0, 0
    end
    EL.property(T.ROCK, "Graphics", rockGfx)
end

print("Mack_New_Elements v12.6 loaded: " .. #ELIST .. " elements. Hover an element to read what it does.")

-- ============================================================
-- Removed in v12.0 (duplicates / invalid names, still removed):
--  STEAM -> VAPR;  BRSS/CPPR/BRZE -> BRAS/COPR/BRNZ;  FRTR -> FERT;
--  FTSL/FRSR -> FRSL;  FNGS -> FUNG;  second MUD entry;
--  STEEL -> STEL and SPORE -> SPOR (names are max 4 letters).
-- ============================================================