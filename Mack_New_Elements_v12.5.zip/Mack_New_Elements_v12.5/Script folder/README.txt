README of Mack_New_Elements_v12.5
-----
-----
Details about this lua script mod:
Name:Mack_New_Elements_v12.5
Credits:
1.Mackeria
2.ChatGPT
3.Claude
Version target(TPT version target): v100.1 
Programmes that are available for this document: TPT/PowderToy
This includes:
1.New elements
2.New gases(elements)
3.New solids(elements)
4.New tools(Tools)
5.New powders(elements)
6.New explosivs(elements
7.New radioactives(elements)

This file includes:
1.Readme(the one you are reading right now)
2.Script folder
3.Compressed/zip folder
4.Notepad with the codes

-----END OF README-----
