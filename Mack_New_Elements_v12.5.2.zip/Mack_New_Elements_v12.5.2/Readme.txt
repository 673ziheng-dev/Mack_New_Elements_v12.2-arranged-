-----Mack_New_Elements_v12.5.1-----

Credits to:
ChatGPT
Mackeria
Claude
-----
Details about this lua script mod:
Name:Mack_New_Elements
Version: v12.5.1(newest)
Target version:v100.0(TPT)
Apps available for this document:TPT/ThePowderToy
This includes:
1.New gases
2.New powders
3.New solids
4.New specials
5.New tools
6.New explosives

Tags:Biology,chemistry,science,nature
Downloaded from GitHub

Developer:Mackeria
Helpers:ChatGPT&Claude


-----END OF README-----

                                                                                                                                                  /:MACKERIA

